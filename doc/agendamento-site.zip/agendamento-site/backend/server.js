import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import fs from "fs";
import PDFDocument from "pdfkit";
import fetch from "node-fetch";
import cron from "node-cron";
import dotenv from "dotenv";
import { google } from "googleapis";
import Database from "better-sqlite3";
import nodemailer from "nodemailer";

dotenv.config();

console.log("SHEET_ID carregado do .env:", process.env.SHEET_ID);

// ======================
// 💾 Banco SQLite
// ======================
const db = new Database("inscricoes.db");

db.exec(`
  CREATE TABLE IF NOT EXISTS inscricoes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    email TEXT NOT NULL,
    telefone TEXT,
    evento_nome TEXT,
    local TEXT,
    ensaio_inicio TEXT,
    ensaio_fim TEXT,
    montagem_inicio TEXT,
    montagem_fim TEXT,
    desmontagem_inicio TEXT,
    desmontagem_fim TEXT,
    eventos_json TEXT,
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

function mapEtapasParaCampos(etapas = []) {
  let ensaio_inicio = null, ensaio_fim = null;
  let montagem_inicio = null, montagem_fim = null;
  let desmontagem_inicio = null, desmontagem_fim = null;
  const eventosExtras = [];

  for (const e of etapas) {
    const nome = (e.nome || "").toLowerCase();
    if (nome === "ensaio") {
      ensaio_inicio = e.inicio || null;
      ensaio_fim = e.fim || null;
    } else if (nome === "montagem") {
      montagem_inicio = e.inicio || null;
      montagem_fim = e.fim || null;
    } else if (nome === "desmontagem") {
      desmontagem_inicio = e.inicio || null;
      desmontagem_fim = e.fim || null;
    } else if (nome === "evento") {
      eventosExtras.push({ inicio: e.inicio, fim: e.fim });
    }
  }

  return {
    ensaio_inicio,
    ensaio_fim,
    montagem_inicio,
    montagem_fim,
    desmontagem_inicio,
    desmontagem_fim,
    eventos_json: JSON.stringify(eventosExtras),
  };
}

const insertInscricao = db.prepare(`
  INSERT INTO inscricoes (
    nome, email, telefone, evento_nome, local,
    ensaio_inicio, ensaio_fim,
    montagem_inicio, montagem_fim,
    desmontagem_inicio, desmontagem_fim,
    eventos_json
  ) VALUES (
    @nome, @email, @telefone, @evento_nome, @local,
    @ensaio_inicio, @ensaio_fim,
    @montagem_inicio, @montagem_fim,
    @desmontagem_inicio, @desmontagem_fim,
    @eventos_json
  );
`);

const app = express();
const port = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));

// ======================
// 📌 Autenticação Google
// ======================
const credentials = JSON.parse(fs.readFileSync("./credentials.json", "utf-8"));

const auth = new google.auth.JWT({
  email: credentials.client_email,
  key: credentials.private_key,
  scopes: [
    "https://www.googleapis.com/auth/calendar",
    "https://www.googleapis.com/auth/spreadsheets.readonly",
    "https://www.googleapis.com/auth/drive.readonly",
  ],
});

const calendar = google.calendar({ version: "v3", auth });
const drive = google.drive({ version: "v3", auth });
const sheets = google.sheets({ version: "v4", auth });

// ======================
// 📧 Enviar e-mail
// ======================
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

async function enviarEmail(destinatario, assunto, mensagem) {
  try {
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: destinatario,
      subject: assunto,
      text: mensagem,
    });
    console.log("📧 E-mail enviado para:", destinatario);
  } catch (err) {
    console.error("❌ Erro ao enviar e-mail:", err.message);
  }
}

// ======================
// IDs das agendas
// ======================
const calendarIds = {
  teatro: "testecris.0001@gmail.com",
  igrejinha:
    "c_e19d30c40d4de176bc7d4e11ada96bfaffd130b3ed499d9807c88785e2c71c05@group.calendar.google.com",
};

// ======================
// 🗂️ Cache em memória
// ======================
let cacheEventos = {};
let lastUpdated = null;

async function atualizarCache() {
  try {
    const agora = new Date();
    const start = agora.toISOString();
    const end = new Date(agora.setMonth(agora.getMonth() + 2)).toISOString();

    for (const [local, calendarId] of Object.entries(calendarIds)) {
      const res = await calendar.events.list({
        calendarId,
        timeMin: start,
        timeMax: end,
        singleEvents: true,
        orderBy: "startTime",
      });

      if (res.data.items) {
        cacheEventos[local] = res.data.items.map((event) => ({
          id: event.id,
          summary: event.summary,
          start: event.start.dateTime || event.start.date + "T00:00:00",
          end: event.end.dateTime || event.end.date + "T23:59:59",
        }));
      }
    }

    lastUpdated = new Date();
    console.log("✅ Cache atualizado em", lastUpdated);
  } catch (err) {
    console.error("❌ Erro ao atualizar cache:", err.message);
  }
}

cron.schedule("*/5 * * * *", atualizarCache);
atualizarCache();

// ======================
// 🌐 Rotas
// ======================
app.get("/ical/:local/horarios", (req, res) => {
  const local = req.params.local;
  console.log("📌 Rota chamada com local:", local);
  console.log("📌 Chaves disponíveis no cache:", Object.keys(cacheEventos));

  if (!cacheEventos[local]) {
    return res.status(503).json({ error: "Cache ainda não carregado" });
  }

  res.json({ lastUpdated, eventos: cacheEventos[local] });
});

app.post("/api/create-events", async (req, res) => {
  const { local, resumo, etapas, userData } = req.body;

  if (!calendarIds[local]) {
    return res.status(400).json({ error: "Calendário não encontrado" });
  }

  try {
    const resultados = [];
    let contadorEventos = 1;

    for (const etapa of etapas) {
      let etapaNome = etapa.nome;
      if (etapa.nome === "evento") {
        etapaNome = `Evento ${contadorEventos}`;
        contadorEventos++;
      }

      const event = {
        summary: `${resumo || userData?.eventName || "Evento"} - ${etapaNome}`,
        description: `Agendado por ${userData.name} (${userData.email}, ${userData.phone})`,
        start: { dateTime: etapa.inicio, timeZone: "America/Sao_Paulo" },
        end: { dateTime: etapa.fim, timeZone: "America/Sao_Paulo" },
      };

      const response = await calendar.events.insert({
        calendarId: calendarIds[local],
        resource: event,
      });

      resultados.push({
        id: response.data.id,
        summary: response.data.summary,
        start: response.data.start,
        end: response.data.end,
      });
    }

    try {
      const campos = mapEtapasParaCampos(etapas);

      insertInscricao.run({
        nome: userData.name,
        email: userData.email,
        telefone: userData.phone,
        evento_nome: userData.eventName,
        local,
        ...campos,
      });

      console.log("✅ Inscrição salva no banco com sucesso!");

      await enviarEmail(
        userData.email,
        "Confirmação de Agendamento",
        `Olá ${userData.name}, seu agendamento foi realizado com sucesso!
📍 Local: ${local}
📅 Evento: ${userData.eventName}`
      );
    } catch (dbErr) {
      console.error("❌ Erro ao salvar no DB:", dbErr);
    }

    await atualizarCache();

    res.json({ success: true, eventosCriados: resultados });
  } catch (err) {
    console.error("❌ Erro ao criar eventos:", err.message);
    res.status(500).json({ error: "Erro ao criar eventos", details: err });
  }
});

// ======================
// 📌 Forms - salvar/ler config.json
// ======================
app.get("/api/forms-link", (req, res) => {
  try {
    const config = JSON.parse(fs.readFileSync("config.json", "utf-8"));
    res.json({ formsLink: config.formsLink || "" });
  } catch {
    res.json({ formsLink: "" });
  }
});

app.post("/api/forms-link", (req, res) => {
  try {
    const { formsLink } = req.body;
    fs.writeFileSync("config.json", JSON.stringify({ formsLink }, null, 2));
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ======================
// 📌 Inscrições (Etapa 1)
// ======================
app.get("/api/inscricoes", (req, res) => {
  try {
    const rows = db.prepare("SELECT * FROM inscricoes").all();
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ======================
// 📌 Respostas do Forms (Etapa 2)
// ======================
app.get("/api/forms-respostas", async (req, res) => {
  try {
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: process.env.SHEET_ID,
      range: process.env.SHEET_RANGE,
    });

    const rows = response.data.values || [];
    const headers = rows[0] || [];

    const respostas = rows.slice(1).map((row) =>
      headers.reduce((acc, h, i) => {
        const val = row[i] || "";

        if (typeof val === "string" && val.includes("drive.google.com")) {
          // Extrair FILE_ID da URL
          const match = val.match(/[-\w]{25,}/);
          const fileId = match ? match[0] : null;

          if (fileId) {
            acc[h] = {
              // Agora salvamos apenas o fileId, o download será feito por uma nova rota
              url: val, // link original
              fileId: fileId,
            };
          } else {
            acc[h] = { url: val };
          }
        } else {
          acc[h] = val;
        }
        return acc;
      }, {})
    );

    res.json({ respostas });
  } catch (err) {
    console.error("❌ Erro ao buscar respostas do Forms:", err.message);
    res.status(500).json({ error: err.message });
  }
});

// ======================
// ⬇️ Rota de Download de Arquivos do Google Drive (Proxy)
// ======================
app.get("/api/download-drive/:fileId", async (req, res) => {
  const { fileId } = req.params;
  try {
    // 1. Usa o Google Drive API para buscar metadados do arquivo
    const fileMetadata = await drive.files.get({
      fileId: fileId,
      fields: "name, mimeType",
    });

    // 2. Define os cabeçalhos da resposta para download
    res.setHeader(
      "Content-Disposition",
      `attachment; filename="${fileMetadata.data.name}"`
    );
    res.setHeader("Content-Type", fileMetadata.data.mimeType);

    // 3. Obtém o stream do arquivo e envia para o cliente
    const fileStream = await drive.files.get(
      { fileId: fileId, alt: "media" },
      { responseType: "stream" }
    );

    fileStream.data
      .on("end", () => console.log("✅ Download do arquivo concluído."))
      .on("error", (err) => {
        console.error("❌ Erro durante o download:", err);
        res.status(500).send("Erro ao baixar o arquivo.");
      })
      .pipe(res);
  } catch (err) {
    console.error("❌ Erro ao baixar arquivo do Drive:", err.message);
    res.status(500).send("Não foi possível baixar o arquivo. Verifique as permissões.");
  }
});

// ======================
// 📄 Rota para gerar PDF
// ======================
app.get("/api/gerar-pdf/:inscricaoId", async (req, res) => {
  const { inscricaoId } = req.params;

  try {
    const inscricao = db.prepare("SELECT * FROM inscricoes WHERE id = ?").get(inscricaoId);
    if (!inscricao) {
      return res.status(404).send("Inscrição não encontrada.");
    }

    const formsResponse = await sheets.spreadsheets.values.get({
      spreadsheetId: process.env.SHEET_ID,
      range: process.env.SHEET_RANGE,
    });

    const formsRows = formsResponse.data.values || [];
    const formsHeaders = formsRows[0] || [];
    const formsData = formsRows.slice(1).map((row) =>
      formsHeaders.reduce((acc, h, i) => {
        acc[h] = row[i] || "";
        return acc;
      }, {})
    );

    const respostaForms = formsData.find((f) => {
      const emailKey = Object.keys(f).find((k) => k.toLowerCase().includes("mail"));
      const emailForms = emailKey ? f[emailKey]?.trim().toLowerCase() : null;
      const telKey = Object.keys(f).find((k) => k.toLowerCase().includes("fone"));
      const telefoneForms = telKey ? f[telKey]?.replace(/\D/g, "") : null;
      const emailEtapa1 = inscricao.email?.trim().toLowerCase();
      const telefoneEtapa1 = inscricao.telefone?.replace(/\D/g, "");
      return (
        (emailForms && emailForms === emailEtapa1) ||
        (telefoneForms && telefoneForms === telefoneEtapa1)
      );
    });

    // 1. Cria o documento PDF em memória
    const doc = new PDFDocument();
    
    // Adiciona o conteúdo ao PDF
    doc.fontSize(20).text("Detalhes da Inscrição", { align: "center" }).moveDown();
    doc.fontSize(14).text(`Título do Evento: ${inscricao.evento_nome || "N/A"}`);
    doc.text(`Local: ${inscricao.local || "N/A"}`).moveDown();
    doc.text(`Nome: ${inscricao.nome || "N/A"}`);
    doc.text(`Email: ${inscricao.email || "N/A"}`);
    doc.text(`Telefone: ${inscricao.telefone || "N/A"}`).moveDown();

    doc.fontSize(16).text("Etapas Agendadas").moveDown(0.5);

    const formatarEtapa = (nome, inicio, fim) => {
      if (!inicio || !fim) return null;
      const data = new Date(inicio).toLocaleDateString("pt-BR");
      const horaInicio = new Date(inicio).toLocaleTimeString("pt-BR", {
        hour: "2-digit",
        minute: "2-digit",
        hour12: false,
      });
      const horaFim = new Date(fim).toLocaleTimeString("pt-BR", {
        hour: "2-digit",
        minute: "2-digit",
        hour12: false,
      });
      doc.text(
        `• ${nome.charAt(0).toUpperCase() + nome.slice(1)}: ${data} das ${horaInicio} às ${horaFim}`
      );
    };

    formatarEtapa("ensaio", inscricao.ensaio_inicio, inscricao.ensaio_fim);
    formatarEtapa("montagem", inscricao.montagem_inicio, inscricao.montagem_fim);

    if (inscricao.eventos_json) {
      const eventosExtras = JSON.parse(inscricao.eventos_json);
      eventosExtras.forEach((ev, i) =>
        formatarEtapa(`evento ${i + 1}`, ev.inicio, ev.fim)
      );
    }

    formatarEtapa(
      "desmontagem",
      inscricao.desmontagem_inicio,
      inscricao.desmontagem_fim
    );

    if (respostaForms) {
      doc.moveDown();
      doc.fontSize(16).text("Informações do Forms").moveDown(0.5);
      for (const key in respostaForms) {
        if (
          key.toLowerCase().includes("mail") ||
          key.toLowerCase().includes("fone")
        )
          continue;
        doc.text(`• ${key}: ${respostaForms[key]}`);
      }
    }

    // 2. Define o cabeçalho para download
    const filename = `inscricao-${inscricaoId}.pdf`;
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);

    // 3. Envia o PDF diretamente para a resposta
    doc.pipe(res);
    doc.end();

  } catch (err) {
    console.error("❌ Erro ao gerar PDF:", err);
    res.status(500).send("Erro ao gerar PDF.");
  }
});

// ======================
// 🚀 Iniciar servidor
// ======================
// Adicione a linha abaixo para servir arquivos estáticos da pasta 'uploads'
app.use("/uploads", express.static("uploads"));

app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});