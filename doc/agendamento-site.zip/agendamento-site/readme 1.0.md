### **Projeto de Agendamento de Espaços Culturais**

Este documento detalha o projeto de um formulário de agendamento online, desenvolvido em **React**, para gerenciar a reserva de dois espaços culturais: o **Teatro** e a **Igrejinha**. O objetivo é criar uma interface interativa e intuitiva que permita aos usuários verificar a disponibilidade de horários em tempo real, agendar eventos e submeter propostas detalhadas.

#### **Funcionalidades Principais**

* **Seleção de Local:** O usuário inicia o processo escolhendo entre os locais "Teatro" e "Igrejinha".  
* **Integração com Google Calendar:** A funcionalidade central do projeto. O aplicativo se conecta diretamente aos calendários do Google para buscar eventos existentes e exibir os horários ocupados, prevenindo agendamentos conflitantes.  
* **Seleção de Múltiplas Etapas:** O formulário permite que o usuário agende diferentes fases para sua proposta, como **Ensaio**, **Montagem**, **Evento (Obrigatório)** e **Desmontagem**.  
* **Formulário Multi-etapas:** A coleta de informações é dividida em um fluxo lógico de várias etapas, incluindo:  
  * Dados do proponente (Pessoa Física ou Jurídica).  
  * Detalhes da Proposta.  
  * Informações de Acessibilidade.  
  * Informações sobre Gratuidade.  
* **Resumo Dinâmico:** Durante o agendamento, um resumo da solicitação é exibido e atualizado em tempo real, permitindo que o usuário visualize e remova etapas com facilidade.

#### **Estrutura do Projeto**

A aplicação é construída com uma arquitetura front-end em **React** e um back-end em **Node.js** com **Express**.

* **Front-end (React):**  
  * App.jsx: Componente principal que gerencia o estado global, o fluxo de navegação entre as etapas e a comunicação com as APIs.  
  * Calendar.jsx: Renderiza o calendário mensal, destacando dias com eventos.  
  * TimeBlockSelector.jsx: Exibe os blocos de horário de 30 minutos, desabilitando os que já estão ocupados.  
  * Componentes de Formulário (PessoaFisicaForm.jsx, Proposta.jsx, etc.): Coletam as informações específicas de cada etapa.  
* **Back-end (Node.js/Express):**  
  * server.js: Define as rotas da API para:  
    * Receber os dados do formulário.  
    * Processar o upload de arquivos.  
    * Gerar um resumo em PDF da inscrição.  
    * (Anteriormente) Servir como proxy para a API do Google Calendar.

#### **Jornada de Desenvolvimento e Soluções Implementadas**

Durante o desenvolvimento, enfrentamos e solucionamos diversos desafios técnicos que foram cruciais para o amadurecimento do projeto:

1. **Conectividade Back-end:** Inicialmente, o front-end não conseguia se comunicar com o back-end, resultando em erros 404 Not Found.  
   * **Solução:** Configuramos um **proxy no Vite (vite.config.js)** para redirecionar as chamadas de API do front-end para o servidor back-end, resolvendo problemas de CORS e simplificando a comunicação entre os dois ambientes.  
2. **Erros de Servidor (Node.js):** O servidor back-end apresentou instabilidade, com erros como require is not defined e Identifier 'PORT' has already been declared.  
   * **Solução:** Padronizamos o server.js para usar a sintaxe de **Módulos ES (import/export)**, alinhando-o com a configuração "type": "module" no package.json. Também corrigimos declarações de variáveis duplicadas, estabilizando o servidor.  
3. **Integração com Google Calendar:** A integração direta com a API do Google apresentou desafios de autorização, como os erros 401: invalid\_client e 403: access\_denied.  
   * **Solução:** Guiamos o processo de configuração no **Google Cloud Console**, incluindo a criação de um **ID de Cliente OAuth 2.0**, a configuração da **Tela de Consentimento** e a adição de **usuários de teste**, o que permitiu que a aplicação obtivesse as permissões necessárias.  
4. **Sincronização de Horários:** Após a conexão bem-sucedida, os horários exibidos no calendário do aplicativo estavam terminando 30 minutos antes do horário real no Google Calendar.  
   * **Solução:** Ajustamos a função fetchOccupiedSlots no App.jsx para **adicionar 30 minutos ao horário de término** de cada evento retornado pela API. Isso garantiu que o último bloco de 30 minutos de um evento fosse corretamente marcado como ocupado, sincronizando perfeitamente a visualização.  
5. **Upload de Arquivos:** A inscrição era concluída, mas os arquivos anexados (currículo, CPF, etc.) não estavam sendo salvos na pasta de uploads.  
   * **Solução:** Corrigimos a lógica no ResumoTotal.jsx para garantir que todos os arquivos fossem corretamente anexados ao FormData em um único array, e ajustamos o server.js para processar e salvar cada arquivo recebido.