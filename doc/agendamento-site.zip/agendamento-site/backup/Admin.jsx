import React, { useState, useEffect } from "react";

const Admin = () => {
  const [formLink, setFormLink] = useState("");
  const [inscricoes, setInscricoes] = useState([]);
  const [loading, setLoading] = useState(true);

  // 🔹 Carregar config do Forms no início
  useEffect(() => {
    fetch("http://localhost:4000/api/forms-link")
      .then((res) => res.json())
      .then((data) => data.formsLink && setFormLink(data.formsLink))
      .catch((err) => console.error("Erro ao carregar link do Forms:", err));
  }, []);

  // 🔹 Função para salvar o link do Forms
  const handleSaveLink = async () => {
    try {
      // O formsLink pode ser do Forms ou da Planilha vinculada.
      // Pegamos o ID (25+ chars alfanuméricos do Google).
      let sheetId = "";
      const match = formLink.match(/[-\w]{25,}/);
      if (match) {
        sheetId = match[0];
      }

      const response = await fetch("http://localhost:4000/api/forms-link", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ formsLink: formLink, sheetId }),
      });

      const result = await response.json();
      if (result.success) {
        alert("✅ Link salvo com sucesso!");
      } else {
        alert("⚠️ Erro ao salvar o link.");
      }
    } catch (error) {
      console.error("Erro ao salvar link:", error);
      alert("❌ Erro na comunicação com o servidor.");
    }
  };

  // 🔹 Função auxiliar para formatar data/hora
  const formatarDataHora = (inicio, fim) => {
    if (!inicio || !fim) return "—";
    const ini = new Date(inicio);
    const fi = new Date(fim);

    const pad = (n) => String(n).padStart(2, "0");
    const data = `${pad(ini.getDate())}/${pad(ini.getMonth() + 1)}/${ini.getFullYear()}`;
    const hora = `${pad(ini.getHours())}:${pad(ini.getMinutes())}`;
    const horaFim = `${pad(fi.getHours())}:${pad(fi.getMinutes())}`;

    return `${data} ${hora}-${horaFim}`;
  };

  // 🔹 Carregar inscrições (etapa 1) e respostas (etapa 2)
  useEffect(() => {
    Promise.all([
      fetch("http://localhost:4000/api/inscricoes").then((r) => r.json()),
      fetch("http://localhost:4000/api/forms-respostas").then((r) => r.json()),
    ])
      .then(([insc, forms]) => {
        const respostas = forms.respostas;

        // unir etapa 1 + etapa 2
        const unificados = insc.map((i) => {
          const matches = respostas.filter((f) => {
            const emailForms = f["E-mail"]?.trim().toLowerCase();
            const telForms = f["Número de telefone (whatsapp)"]?.replace(/\D/g, "");
            const emailEtapa1 = i.email?.trim().toLowerCase();
            const telEtapa1 = i.telefone?.replace(/\D/g, "");
            return emailForms === emailEtapa1 || telForms === telEtapa1;
          });

          const ultimaResposta = matches[matches.length - 1];
          const anexos = ultimaResposta
            ? Object.entries(ultimaResposta)
                .filter(([key, val]) => key.toLowerCase().includes("documento") && val && val.url)
                .map(([_, val]) => val)
            : [];

          return { ...i, anexos };
        });

        setInscricoes(unificados);
      })
      .catch((err) => console.error("Erro ao carregar dados:", err))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Painel Administrativo</h1>

      {/* 🔹 Campo de link do Forms */}
      <div className="mb-6">
        <label className="block font-medium">
  Link do Google Forms ou Planilha:
</label>

        <input
          type="text"
          value={formLink}
          onChange={(e) => setFormLink(e.target.value)}
          className="border p-2 w-full rounded"
          placeholder="Cole aqui o link do Forms ou da Planilha"
        />
        <button
          onClick={handleSaveLink}
          className="mt-2 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          Salvar
        </button>
      </div>

      {loading ? (
        <p>Carregando...</p>
      ) : (
        <div className="border rounded p-4">
          <h2 className="text-lg font-semibold mb-3">📋 Inscrições</h2>
          <table className="border-collapse border w-full text-sm">
            <thead className="bg-gray-200">
              <tr>
                <th className="border px-2 py-1">Título</th>
                <th className="border px-2 py-1">Etapas</th>
                <th className="border px-2 py-1">Anexos</th>
              </tr>
            </thead>
            <tbody>
              {inscricoes.map((i, idx) => {
                const eventosExtras = i.eventos_json ? JSON.parse(i.eventos_json) : [];
                return (
                  <tr key={idx}>
                    <td className="border px-2 py-1">{i.evento_nome}</td>
                    <td className="border px-2 py-1 whitespace-pre-line">
                      {i.ensaio_inicio && i.ensaio_fim && (
                        <>ensaio: {formatarDataHora(i.ensaio_inicio, i.ensaio_fim)}{"\n"}</>
                      )}
                      {i.montagem_inicio && i.montagem_fim && (
                        <>montagem: {formatarDataHora(i.montagem_inicio, i.montagem_fim)}{"\n"}</>
                      )}
                      {eventosExtras.length > 0 &&
                        eventosExtras.map((ev, j) => (
                          <div key={j}>
                            evento {j + 1}: {formatarDataHora(ev.inicio, ev.fim)}
                          </div>
                        ))}
                      {i.desmontagem_inicio && i.desmontagem_fim && (
                        <>desmontagem: {formatarDataHora(i.desmontagem_inicio, i.desmontagem_fim)}</>
                      )}
                    </td>
                    <td className="border px-2 py-1">
                      {i.anexos && i.anexos.length > 0 ? (
                        <ul className="list-disc ml-4 text-sm">
                          {i.anexos.map((arq, j) => (
                            <li key={j}>
                              <a
                                href={arq.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-blue-600 hover:underline"
                              >
                                {arq.name}
                              </a>
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <span className="text-gray-400">—</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default Admin;
