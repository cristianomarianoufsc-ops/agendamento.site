import React, { useState, useEffect } from "react";
import Calendar from "./components/Calendar";
import TimeBlockSelector from "./components/TimeBlockSelector";
import PessoaFisicaForm from "./components/PessoaFisicaForm";
import PessoaJuridicaForm from "./components/PessoaJuridicaForm";
import Proposta from "./components/Proposta";
import DadosDaProposta from "./components/DadosDaProposta";
import ResumoProposta from "./components/ResumoProposta";
import AcessComu from "./components/AcessComu";
import Gratuidade from "./components/Gratuidade";
import ResumoTotal from "./components/ResumoTotal";

// Constantes para autenticação e acesso à API do Google
const GOOGLE_API_KEY = "AIzaSyAQR9zPi34W1jHKXVMqujkRapS2AxpEPQE";
const GOOGLE_CALENDAR_ID_TEATRO = "oto.bezerra@ufsc.br";
const GOOGLE_CALENDAR_ID_IGREJINHA =
  "c_e19d30c40d4de176bc7d4e11ada96bfaffd130b3ed499d9807c88785e2c71c05@group.calendar.google.com";
const DISCOVERY_DOCS = [
  "https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest",
];

const App = () => {
  const [localSelecionado, setLocalSelecionado] = useState(null);
  const [selectedStage, setSelectedStage] = useState(null);
  const [selectedDate, setSelectedDate] = useState(null);
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [etapasSelecionadas, setEtapasSelecionadas] = useState([]);
  const [stageTimes, setStageTimes] = useState({ startTime: null, endTime: null });
  const [resumo, setResumo] = useState({ evento: [] });
  const [dadosPessoa, setDadosPessoa] = useState(null);
  const [dadosProposta, setDadosProposta] = useState(null);
  const [dadosAcessibilidade, setDadosAcessibilidade] = useState(null);
  const [dadosGratuidade, setDadosGratuidade] = useState(null);
  const [backendOcupados, setBackendOcupados] = useState({});
  const [currentStep, setCurrentStep] = useState("select_local");
  const [arquivos, setArquivos] = useState({});
  const [showErrorMessage, setShowErrorMessage] = useState(false);

  const timeSlots = [
    "08:00", "08:30", "09:00", "09:30", "10:00", "10:30",
    "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
    "14:00", "14:30", "15:00", "15:30", "16:00", "16:30",
    "17:00", "17:30", "18:00", "18:30", "19:00", "19:30",
    "20:00", "20:30", "21:00", "21:30", "22:00"
  ];

  const stageOrder = ["ensaio", "montagem", "evento", "desmontagem"];

  // Efeito para carregar a biblioteca do Google
  useEffect(() => {
    const scriptGapi = document.createElement("script");
    scriptGapi.src = "https://apis.google.com/js/api.js";
    scriptGapi.onload = () => {
      window.gapi.load("client", () => {
        window.gapi.client.init({
          apiKey: GOOGLE_API_KEY,
          discoveryDocs: DISCOVERY_DOCS,
        });
      });
    };
    document.body.appendChild(scriptGapi);
  }, []);

  // Buscar horários ocupados sempre que o local ou o mês mudar
  useEffect(() => {
    if (localSelecionado) {
      fetchOccupiedSlots(localSelecionado, currentMonth);
    }
  }, [localSelecionado, currentMonth]);

  // Buscar eventos do calendário público
  const fetchOccupiedSlots = async (local, month) => {
    const calendarId =
      local === "teatro" ? GOOGLE_CALENDAR_ID_TEATRO : GOOGLE_CALENDAR_ID_IGREJINHA;

    const year = month.getFullYear();
    const monthIndex = month.getMonth();
    const firstDayOfMonth = new Date(year, monthIndex, 1);
    const lastDayOfMonth = new Date(year, monthIndex + 1, 0);

    try {
      const response = await window.gapi.client.calendar.events.list({
        calendarId: calendarId,
        timeMin: firstDayOfMonth.toISOString(),
        timeMax: lastDayOfMonth.toISOString(),
        showDeleted: false,
        singleEvents: true,
        orderBy: "startTime",
      });

      const events = response.result.items;
      const occupiedByDate = {};
      events.forEach((event) => {
        const start = new Date(event.start.dateTime || event.start.date);
        const end = new Date(event.end.dateTime || event.end.date);
        end.setMinutes(end.getMinutes() + 30); // margem de segurança
        const dateString = start.toISOString().split("T")[0];
        const startTime = start.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", hour12: false });
        const endTime = end.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", hour12: false });
        if (!occupiedByDate[dateString]) {
          occupiedByDate[dateString] = [];
        }
        occupiedByDate[dateString].push({ start: startTime, end: endTime });
      });

      setBackendOcupados(occupiedByDate);
    } catch (error) {
      console.error("Erro ao buscar eventos do Google Calendar:", error);
      setBackendOcupados({});
    }
  };

  const handleLocalSelect = (local) => {
    setLocalSelecionado(local);
    setCurrentStep("calendar");
  };

  const handleDateSelect = (date) => {
    setSelectedDate(date);
    setStageTimes({ startTime: null, endTime: null });
  };

  const getOccupiedSlots = (date) => {
    if (!date) return [];
    const dateString = date.toISOString().split("T")[0];
    return backendOcupados[dateString] || [];
  };

  const confirmStage = (etapa) => {
    if (selectedDate && stageTimes.startTime && stageTimes.endTime) {
      setResumo((prevResumo) => {
        const newResumo = { ...prevResumo };
        const newEntry = {
          date: selectedDate.toISOString(),
          start: stageTimes.startTime,
          end: stageTimes.endTime,
        };
        if (etapa === "evento") {
          newResumo.evento = [...(newResumo.evento || []), newEntry];
        } else {
          newResumo[etapa] = newEntry;
        }
        return newResumo;
      });
      setEtapasSelecionadas((prev) => {
        if (!prev.includes(etapa)) {
          return [...prev, etapa].sort(
            (a, b) => stageOrder.indexOf(a) - stageOrder.indexOf(b)
          );
        }
        return prev;
      });
      setSelectedStage(null);
      setSelectedDate(null);
      setStageTimes({ startTime: null, endTime: null });
    }
  };

  const handleNextCalendarStep = () => {
    if (resumo.evento && resumo.evento.length > 0) {
      setCurrentStep("select_person_type");
    } else {
      setShowErrorMessage(true);
    }
  };

  const handlePersonTypeSelect = (type) => {
    setDadosPessoa({ tipo: type });
    if (type === "fisica") {
      setCurrentStep("pessoa_fisica_form");
    } else {
      setCurrentStep("pessoa_juridica_form");
    }
  };

  const handleUpload = (key, file) => {
    setArquivos((prev) => ({ ...prev, [key]: file }));
  };

  const dadosCompletos = {
    localSelecionado,
    resumoAgendamento: resumo,
    dadosPessoa,
    dadosProposta,
    dadosAcessibilidade,
    dadosGratuidade,
    arquivos,
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold text-center mb-6">
        Agendamento de Espaços Culturais
      </h1>

      {/* FLUXO PRINCIPAL */}
      {currentStep === "select_local" && (
        <div className="flex flex-col items-center justify-center min-h-[50vh]">
          <ul className="list-disc list-inside text-gray-700 mb-6 px-4 text-sm max-w-2xl text-left">
            <li>Verificar previamente a disponibilidade do espaço requisitado na agenda deste formulário;</li>
            <li>Registrar todos os períodos necessários à realização da proposta, incluindo montagem, ensaio, realização do evento e desmontagem;</li>
            <li>Para eventos com cobrança de ingresso, a taxa de locação será calculada com base em todos os períodos reservados;</li>
            <li>Respeitar os prazos para solicitação de reserva do espaço;</li>
            <li>A confirmação da disponibilidade de uso será feita posteriormente pela equipe do DAC.</li>
          </ul>

          <h2 className="text-2xl font-bold mb-4">Selecione o Local</h2>
          <div className="flex gap-4">
            <button
              onClick={() => handleLocalSelect("teatro")}
              className="px-6 py-3 bg-indigo-600 text-white rounded-lg shadow-md hover:bg-indigo-700 transition duration-300"
            >
              Teatro
            </button>
            <button
              onClick={() => handleLocalSelect("igrejinha")}
              className="px-6 py-3 bg-purple-600 text-white rounded-lg shadow-md hover:bg-purple-700 transition duration-300"
            >
              Igrejinha
            </button>
          </div>
        </div>
      )}

      {currentStep === "calendar" && (
        <div>
          <h2 className="text-xl font-bold mb-4">
            Local Selecionado: {localSelecionado === "teatro" ? "Teatro" : "Igrejinha"}
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h3 className="font-semibold mb-2">Selecione as Etapas:</h3>
              {stageOrder.map((etapa) => (
                <button
                  key={etapa}
                  onClick={() => {
                    setSelectedStage((prevStage) =>
                      prevStage === etapa ? null : etapa
                    );
                    setSelectedDate(null);
                    setStageTimes({ startTime: null, endTime: null });
                  }}
                  className={`block w-full text-left p-2 mb-2 rounded ${
                    selectedStage === etapa
                      ? "bg-blue-500 text-white"
                      : "bg-gray-200"
                  }`}
                >
                  {etapa.charAt(0).toUpperCase() + etapa.slice(1)}{" "}
                  {etapa === "evento" ? "(Obrigatório)" : ""}
                </button>
              ))}
            </div>

            <div>
              {selectedStage && (
                <Calendar
                  onDateSelect={handleDateSelect}
                  currentMonth={currentMonth}
                  onMonthChange={setCurrentMonth}
                  disabledDates={Object.keys(backendOcupados).filter((date) => {
                    const occupiedTimes = backendOcupados[date];
                    return occupiedTimes && occupiedTimes.length === timeSlots.length;
                  })}
                  eventDates={Object.keys(backendOcupados)}
                  mainEventDatesSelected={resumo.evento.map(
                    (e) => new Date(e.date)
                  )}
                  currentStage={selectedStage}
                />
              )}

              {selectedDate && selectedStage && (
                <TimeBlockSelector
                  selectedDate={selectedDate}
                  timeSlots={timeSlots}
                  selectedTimes={stageTimes}
                  onSelectTime={(time) => {
                    setStageTimes((prev) => {
                      if (!prev.startTime)
                        return { startTime: time, endTime: null };
                      if (time === prev.startTime)
                        return { startTime: null, endTime: null };
                      if (time < prev.startTime)
                        return { startTime: time, endTime: null };
                      if (time > prev.startTime)
                        return { ...prev, endTime: time };
                      return { startTime: time, endTime: null };
                    });
                  }}
                  occupiedSlots={getOccupiedSlots(selectedDate)}
                  stage={selectedStage}
                />
              )}

              {selectedDate && stageTimes.startTime && stageTimes.endTime && (
                <button
                  onClick={() => confirmStage(selectedStage)}
                  className="mt-2 px-4 py-2 bg-green-600 text-white rounded"
                >
                  Confirmar{" "}
                  {selectedStage === "evento" ? "Evento" : selectedStage}
                </button>
              )}
            </div>
          </div>

          <div className="mt-6 p-4 border rounded bg-gray-50">
            <h3 className="font-bold mb-2">Resumo da Solicitação</h3>
            {(!resumo.evento.length &&
              Object.keys(resumo).filter((k) => k !== "evento").length === 0) && (
              <p className="text-sm text-gray-500">Nenhum agendamento feito.</p>
            )}
            <ul className="text-sm">
              {stageOrder.map((etapaOrdenada) => {
                const dados = resumo[etapaOrdenada];
                if (etapaOrdenada === "evento" && dados && dados.length > 0) {
                  return (
                    <li key={etapaOrdenada} className="mb-1">
                      <strong>
                        {etapaOrdenada.charAt(0).toUpperCase() +
                          etapaOrdenada.slice(1)}
                        :
                      </strong>
                      <ul>
                        {dados.map((eventoItem, idx) => (
                          <li
                            key={idx}
                            className="mb-1 flex items-center justify-between ml-4"
                          >
                            <div>
                              {new Date(
                                eventoItem.date
                              ).toLocaleDateString()}{" "}
                              de {eventoItem.start} até {eventoItem.end}
                            </div>
                            <button
                              onClick={() => {
                                setResumo((prevResumo) => {
                                  const newEventos = prevResumo.evento.filter(
                                    (_, i) => i !== idx
                                  );
                                  return { ...prevResumo, evento: newEventos };
                                });
                              }}
                              className="ml-2 px-2 py-1 bg-red-500 text-white rounded text-xs"
                            >
                              Remover
                            </button>
                          </li>
                        ))}
                      </ul>
                    </li>
                  );
                } else if (dados && dados.date) {
                  const displayEtapa =
                    etapaOrdenada.charAt(0).toUpperCase() +
                    etapaOrdenada.slice(1);
                  return (
                    <li
                      key={etapaOrdenada}
                      className="mb-1 flex items-center justify-between"
                    >
                      <div>
                        <strong>{displayEtapa}:</strong>{" "}
                        {new Date(dados.date).toLocaleDateString()} de{" "}
                        {dados.start} até {dados.end}
                      </div>
                      <button
                        onClick={() =>
                          setResumo((prevResumo) => {
                            const newResumo = { ...prevResumo };
                            if (etapaOrdenada === "evento") {
                              newResumo.evento = [];
                            } else {
                              delete newResumo[etapaOrdenada];
                            }
                            return newResumo;
                          })
                        }
                        className="ml-2 px-2 py-1 bg-red-500 text-white rounded text-xs"
                      >
                        Remover
                      </button>
                    </li>
                  );
                }
                return null;
              })}
            </ul>
          </div>

          {resumo.evento && resumo.evento.length > 0 && (
            <div className="flex justify-center mt-4">
              <button
                onClick={handleNextCalendarStep}
                className="px-4 py-2 bg-blue-600 text-white rounded"
              >
                Salvar e Continuar
              </button>
            </div>
          )}
        </div>
      )}

      {currentStep === "select_person_type" && (
        <div className="flex flex-col items-center justify-center p-8 bg-white rounded-lg shadow-md">
          <h2 className="text-2xl font-bold mb-6 text-center">
            Você é Pessoa Física ou Jurídica?
          </h2>
          <div className="flex gap-4">
            <button
              onClick={() => handlePersonTypeSelect("fisica")}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg shadow-md hover:bg-blue-700 transition duration-300"
            >
              Pessoa Física
            </button>
            <button
              onClick={() => handlePersonTypeSelect("juridica")}
              className="px-6 py-3 bg-green-600 text-white rounded-lg shadow-md hover:bg-green-700 transition duration-300"
            >
              Pessoa Jurídica
            </button>
          </div>
          <button
            onClick={() => setCurrentStep("calendar")}
            className="mt-6 px-6 py-3 bg-gray-500 text-white rounded-lg shadow-md hover:bg-gray-600 transition duration-300"
          >
            Voltar para Calendário
          </button>
        </div>
      )}

      {currentStep === "pessoa_fisica_form" && (
        <PessoaFisicaForm
          onNext={(dados) => {
            setDadosPessoa((prev) => ({ ...prev, ...dados }));
            setCurrentStep("proposta_form");
          }}
          onBack={() => setCurrentStep("select_person_type")}
          onUpload={handleUpload}
        />
      )}

      {currentStep === "pessoa_juridica_form" && (
        <PessoaJuridicaForm
          onNext={(dados) => {
            setDadosPessoa((prev) => ({ ...prev, ...dados }));
            setCurrentStep("proposta_form");
          }}
          onBack={() => setCurrentStep("select_person_type")}
          onUpload={handleUpload}
        />
      )}

      {currentStep === "proposta_form" && (
        <Proposta
          onNext={(dados) => {
            setDadosProposta(dados);
            setCurrentStep("dados_proposta_form");
          }}
          onBack={() =>
            setCurrentStep(
              dadosPessoa?.tipo === "fisica"
                ? "pessoa_fisica_form"
                : "pessoa_juridica_form"
            )
          }
        />
      )}

      {currentStep === "dados_proposta_form" && (
        <DadosDaProposta
          onNext={(dados) => {
            setDadosProposta((prev) => ({ ...prev, ...dados }));
            setCurrentStep("resumo_proposta");
          }}
          onBack={() => setCurrentStep("proposta_form")}
        />
      )}

      {currentStep === "resumo_proposta" && (
        <ResumoProposta
          onNext={() => setCurrentStep("acessibilidade_form")}
          onBack={() => setCurrentStep("dados_proposta_form")}
          dadosCompletos={dadosCompletos}
        />
      )}

      {currentStep === "acessibilidade_form" && (
        <AcessComu
          onNext={(dados) => {
            setDadosAcessibilidade(dados);
            setCurrentStep("gratuidade_form");
          }}
          onBack={() => setCurrentStep("resumo_proposta")}
        />
      )}

      {currentStep === "gratuidade_form" && (
        <Gratuidade
          onNext={(dados) => {
            setDadosGratuidade(dados);
            setCurrentStep("resumo_total");
          }}
          onBack={() => setCurrentStep("acessibilidade_form")}
        />
      )}

      {currentStep === "resumo_total" && (
        <ResumoTotal
          dadosCompletos={dadosCompletos}
          onBack={() => setCurrentStep("gratuidade_form")}
        />
      )}

      {/* Modal de Erro */}
      {showErrorMessage && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white p-6 rounded-lg shadow-xl text-center max-w-sm">
            <h3 className="text-lg font-bold text-red-600 mb-4">Atenção!</h3>
            <p className="text-gray-700 mb-6">
              É obrigatório agendar pelo menos um Evento Principal antes de continuar.
            </p>
            <button
              onClick={() => setShowErrorMessage(false)}
              className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600 transition duration-300"
            >
              Entendi
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;