import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import fs from "fs";
import cron from "node-cron";
import dotenv from "dotenv";
import { google } from "googleapis";
import Database from "better-sqlite3";
import nodemailer from "nodemailer";

dotenv.config();

// ======================
// 💾 Banco SQLite
// ======================
const db = new Database("inscricoes.db");

db.exec(`
  CREATE TABLE IF NOT EXISTS inscricoes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    email TEXT NOT NULL,
    telefone TEXT,
    evento_nome TEXT,
    local TEXT,
    ensaio_inicio TEXT,
    ensaio_fim TEXT,
    montagem_inicio TEXT,
    montagem_fim TEXT,
    desmontagem_inicio TEXT,
    desmontagem_fim TEXT,
    eventos_json TEXT,
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

function mapEtapasParaCampos(etapas = []) {
  let ensaio_inicio = null, ensaio_fim = null;
  let montagem_inicio = null, montagem_fim = null;
  let desmontagem_inicio = null, desmontagem_fim = null;
  const eventosExtras = [];

  for (const e of etapas) {
    const nome = (e.nome || "").toLowerCase();
    if (nome === "ensaio") {
      ensaio_inicio = e.inicio || null;
      ensaio_fim = e.fim || null;
    } else if (nome === "montagem") {
      montagem_inicio = e.inicio || null;
      montagem_fim = e.fim || null;
    } else if (nome === "desmontagem") {
      desmontagem_inicio = e.inicio || null;
      desmontagem_fim = e.fim || null;
    } else if (nome === "evento") {
      eventosExtras.push({ inicio: e.inicio, fim: e.fim });
    }
  }

  return {
    ensaio_inicio,
    ensaio_fim,
    montagem_inicio,
    montagem_fim,
    desmontagem_inicio,
    desmontagem_fim,
    eventos_json: JSON.stringify(eventosExtras),
  };
}

const insertInscricao = db.prepare(`
  INSERT INTO inscricoes (
    nome, email, telefone, evento_nome, local,
    ensaio_inicio, ensaio_fim,
    montagem_inicio, montagem_fim,
    desmontagem_inicio, desmontagem_fim,
    eventos_json
  ) VALUES (
    @nome, @email, @telefone, @evento_nome, @local,
    @ensaio_inicio, @ensaio_fim,
    @montagem_inicio, @montagem_fim,
    @desmontagem_inicio, @desmontagem_fim,
    @eventos_json
  );
`);

const app = express();
const port = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));

// ======================
// 📌 Autenticação Google
// ======================
const credentials = JSON.parse(fs.readFileSync("./credentials.json", "utf-8"));

const auth = new google.auth.JWT({
  email: credentials.client_email,
  key: credentials.private_key,
  scopes: [
    "https://www.googleapis.com/auth/calendar",
    "https://www.googleapis.com/auth/spreadsheets.readonly",
    "https://www.googleapis.com/auth/drive.readonly",
  ],
});

const calendar = google.calendar({ version: "v3", auth });
const drive = google.drive({ version: "v3", auth });
const sheets = google.sheets({ version: "v4", auth });

// ======================
// 📧 Enviar e-mail
// ======================
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

async function enviarEmail(destinatario, assunto, mensagem) {
  try {
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: destinatario,
      subject: assunto,
      text: mensagem,
    });
    console.log("📧 E-mail enviado para:", destinatario);
  } catch (err) {
    console.error("❌ Erro ao enviar e-mail:", err.message);
  }
}

// ======================
// IDs das agendas
// ======================
const calendarIds = {
  teatro: "testecris.0001@gmail.com",
  igrejinha:
    "c_e19d30c40d4de176bc7d4e11ada96bfaffd130b3ed499d9807c88785e2c71c05@group.calendar.google.com",
};

// ======================
// 🗂️ Cache em memória
// ======================
let cacheEventos = {};
let lastUpdated = null;

async function atualizarCache() {
  try {
    const agora = new Date();
    const start = agora.toISOString();
    const end = new Date(agora.setMonth(agora.getMonth() + 2)).toISOString();

    for (const [local, calendarId] of Object.entries(calendarIds)) {
      const res = await calendar.events.list({
        calendarId,
        timeMin: start,
        timeMax: end,
        singleEvents: true,
        orderBy: "startTime",
      });

      if (res.data.items) {
        cacheEventos[local] = res.data.items.map((event) => ({
          id: event.id,
          summary: event.summary,
          start: event.start.dateTime || event.start.date + "T00:00:00",
          end: event.end.dateTime || event.end.date + "T23:59:59",
        }));
      }
    }

    lastUpdated = new Date();
    console.log("✅ Cache atualizado em", lastUpdated);
  } catch (err) {
    console.error("❌ Erro ao atualizar cache:", err.message);
  }
}

cron.schedule("*/5 * * * *", atualizarCache);
atualizarCache();

// ======================
// 🌐 Rotas
// ======================
app.get("/ical/:local/horarios", (req, res) => {
  const { local } = req.params;
  if (!cacheEventos[local]) {
    return res.status(503).json({ error: "Cache ainda não carregado" });
  }
  res.json({ lastUpdated, eventos: cacheEventos[local] });
});

// ======================
// 📌 Criar eventos no calendário
// ======================
app.post("/api/create-events", async (req, res) => {
  const { local, resumo, etapas, userData } = req.body;

  if (!calendarIds[local]) {
    return res.status(400).json({ error: "Calendário não encontrado" });
  }

  try {
    const resultados = [];
    let contadorEventos = 1;

    for (const etapa of etapas) {
      let etapaNome = etapa.nome;
      if (etapa.nome === "evento") {
        etapaNome = `Evento ${contadorEventos}`;
        contadorEventos++;
      }

      const event = {
        summary: `${resumo || userData?.eventName || "Evento"} - ${etapaNome}`,
        description: `Agendado por ${userData.name} (${userData.email}, ${userData.phone})`,
        start: { dateTime: etapa.inicio, timeZone: "America/Sao_Paulo" },
        end: { dateTime: etapa.fim, timeZone: "America/Sao_Paulo" },
      };

      const response = await calendar.events.insert({
        calendarId: calendarIds[local],
        resource: event,
      });

      resultados.push({
        id: response.data.id,
        summary: response.data.summary,
        start: response.data.start,
        end: response.data.end,
      });
    }

    try {
      const campos = mapEtapasParaCampos(etapas);

      insertInscricao.run({
        nome: userData.name,
        email: userData.email,
        telefone: userData.phone,
        evento_nome: userData.eventName,
        local,
        ...campos,
      });

      console.log("✅ Inscrição salva no banco com sucesso!");

      await enviarEmail(
        userData.email,
        "Confirmação de Agendamento",
        `Olá ${userData.name}, seu agendamento foi realizado com sucesso!
📍 Local: ${local}
📅 Evento: ${userData.eventName}`
      );
    } catch (dbErr) {
      console.error("❌ Erro ao salvar no DB:", dbErr);
    }

    await atualizarCache();

    res.json({ success: true, eventosCriados: resultados });
  } catch (err) {
    console.error("❌ Erro ao criar eventos:", err.message);
    res.status(500).json({ error: "Erro ao criar eventos", details: err });
  }
});

// ======================
// 📌 Forms - salvar/ler link da planilha
// ======================
app.get("/api/forms-link", (req, res) => {
  try {
    const config = JSON.parse(fs.readFileSync("config.json", "utf-8"));
    res.json({ formsLink: config.formsLink || "", sheetId: config.sheetId || "" });
  } catch {
    res.json({ formsLink: "", sheetId: "" });
  }
});

app.post("/api/forms-link", async (req, res) => {
  try {
    let { formsLink } = req.body;
    let sheetId = "";

    if (formsLink.includes("spreadsheets")) {
      // Extrai o ID da planilha
      const match = formsLink.match(/[-\w]{25,}/);
      if (match) sheetId = match[0];
    }

    if (!sheetId) {
      return res.status(400).json({ success: false, error: "Link de planilha inválido." });
    }

    // 🔹 Salva config no arquivo
    fs.writeFileSync(
      "config.json",
      JSON.stringify({ formsLink, sheetId }, null, 2)
    );

    res.json({ success: true, sheetId });
  } catch (err) {
    console.error("❌ Erro em /api/forms-link:", err.message);
    res.status(500).json({ success: false, error: err.message });
  }
});

// ======================
// 📌 Buscar respostas da planilha vinculada
// ======================
app.get("/api/forms-respostas", async (req, res) => {
  try {
    const config = JSON.parse(fs.readFileSync("config.json", "utf-8"));
    const sheetId = config.sheetId;

    if (!sheetId) {
      return res.status(400).json({ error: "Sheet ID não configurado. Cole o link da planilha no painel administrativo." });
    }

    const range = process.env.SHEET_RANGE || "Respostas ao formulário 1";

    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: sheetId,
      range,
    });

    const rows = response.data.values || [];
    if (rows.length === 0) {
      return res.json([]);
    }

    const headers = rows[0];
    const respostas = [];

    for (const row of rows.slice(1)) {
      const obj = {};
      for (let i = 0; i < headers.length; i++) {
        let val = row[i] || "";

        // Se for link do Google Drive, pega detalhes do arquivo
        if (typeof val === "string" && val.includes("drive.google.com")) {
          const match = val.match(/[-\w]{25,}/);
          const fileId = match ? match[0] : null;

          if (fileId) {
            try {
              const fileInfo = await drive.files.get({
                fileId,
                fields: "id, name, webViewLink",
              });
              obj[headers[i]] = {
                url: fileInfo.data.webViewLink,
                name: fileInfo.data.name,
                download: `https://drive.google.com/uc?export=download&id=${fileId}`,
              };
            } catch {
              obj[headers[i]] = { url: val, name: "Arquivo", download: val };
            }
          } else {
            obj[headers[i]] = { url: val, name: "Arquivo", download: val };
          }
        } else {
          obj[headers[i]] = val;
        }
      }

      respostas.push({
        id: row[0],
        titulo: obj["Evento"] || obj["Nome do evento"] || "Sem título",
        etapas: [
          obj["Etapa"] || obj["Período"] || "Sem etapa definida"
        ],
        anexos: Object.values(obj).filter(v => typeof v === "object" && v.url),
        criado_em: row[0] || new Date().toISOString(),
      });
    }

    res.json(respostas);
  } catch (err) {
    console.error("❌ Erro ao buscar respostas do Forms:", err.message);
    res.status(500).json({ error: err.message });
  }
});

// ======================
// 📌 Listar inscrições formatadas (etapa 1)
// ======================
app.get("/api/inscricoes", (req, res) => {
  try {
    const rows = db.prepare("SELECT * FROM inscricoes ORDER BY criado_em DESC").all();

    const inscricoes = rows.map((row) => {
      const etapas = [];
      if (row.ensaio_inicio && row.ensaio_fim) etapas.push(`Ensaio: ${row.ensaio_inicio} → ${row.ensaio_fim}`);
      if (row.montagem_inicio && row.montagem_fim) etapas.push(`Montagem: ${row.montagem_inicio} → ${row.montagem_fim}`);
      if (row.desmontagem_inicio && row.desmontagem_fim) etapas.push(`Desmontagem: ${row.desmontagem_inicio} → ${row.desmontagem_fim}`);

      try {
        const extras = JSON.parse(row.eventos_json || "[]");
        extras.forEach((e, idx) => etapas.push(`Evento ${idx + 1}: ${e.inicio} → ${e.fim}`));
      } catch {}

      return {
        id: row.id,
        titulo: row.evento_nome || "Sem título",
        etapas: etapas,
        anexos: [],
        criado_em: row.criado_em,
      };
    });

    res.json(inscricoes);
  } catch (err) {
    console.error("❌ Erro ao listar inscrições:", err.message);
    res.status(500).json({ error: "Erro ao buscar inscrições" });
  }
});

// ======================
// 🚀 Iniciar servidor
// ======================
app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});
