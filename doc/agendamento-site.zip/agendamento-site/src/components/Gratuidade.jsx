import React, { useState } from "react";

const EDITAL_LINK = "https://secarte.paginas.ufsc.br/files/2025/05/Edital-018-_de-Ocupa%C3%A7%C3%A3o-Externo-DAC_Assinado_.pdf";

function Gratuidade({ onNext, onBack }) {
    const [gratuidade, setGratuidade] = useState(null);
    const [observacoes, setObservacoes] = useState("");

    const handleGratuidadeChange = (resposta) => {
        setGratuidade(resposta);
    };

    const handleSaveAndContinue = () => {
        onNext({
            gratuito: gratuidade,
            observacoes: observacoes,
        });
    };

    const isNextButtonEnabled = gratuidade !== null;

    return (
        <div className="mt-6 p-4 border rounded shadow-lg">
            <h2 className="text-xl font-bold mb-4">Gratuidade do Evento</h2>
            
            <div className="mb-4">
                <p className="block mb-2 font-semibold">O evento será gratuito? *</p>
                <div className="flex gap-4 mt-2">
                    <button
                        onClick={() => handleGratuidadeChange("sim")}
                        className={`px-4 py-2 rounded ${gratuidade === "sim" ? "bg-blue-600 text-white font-bold" : "bg-gray-200"}`}
                    >
                        Sim
                    </button>
                    <button
                        onClick={() => handleGratuidadeChange("nao")}
                        className={`px-4 py-2 rounded ${gratuidade === "nao" ? "bg-blue-600 text-white font-bold" : "bg-gray-200"}`}
                    >
                        Não
                    </button>
                </div>
            </div>

            <div className="mt-4">
                <label className="block mb-2 font-semibold">Observações (Opcional):</label>
                <textarea
                    value={observacoes}
                    onChange={(e) => setObservacoes(e.target.value)}
                    className="border p-2 w-full h-24"
                />
            </div>
            
            {gratuidade === "nao" && (
                <div className="p-4 bg-yellow-50 border-l-4 border-yellow-400 text-yellow-700 mt-4">
                    <p>
                        Saiba mais no ítem 11 do edital <a href={EDITAL_LINK} target="_blank" rel="noopener noreferrer" className="font-bold underline hover:text-yellow-900">clicando aqui</a>.
                    </p>
                </div>
            )}

            <div className="flex justify-between mt-6">
                <button
                    className="bg-gray-400 text-white px-4 py-2 rounded hover:bg-gray-500"
                    onClick={onBack}
                >
                    Voltar
                </button>
                <button
                    onClick={handleSaveAndContinue}
                    disabled={!isNextButtonEnabled}
                    className={`px-4 py-2 rounded ${isNextButtonEnabled ? "bg-purple-600 text-white hover:bg-purple-700" : "bg-gray-300 text-gray-500 cursor-not-allowed"}`}
                >
                    Salvar e Continuar
                </button>
            </div>
        </div>
    );
}

export default Gratuidade;