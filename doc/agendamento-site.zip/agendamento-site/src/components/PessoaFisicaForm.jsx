// src/components/PessoaFisicaForm.jsx
import React, { useState } from "react";

function PessoaFisicaForm({ onNext, onBack }) {
  const [formData, setFormData] = useState({
    nomeCompleto: "",
    email: "",
    telefone: "",
    endereco: {
      cep: "",
      logradouro: "",
      numero: "",
      bairro: "",
      cidade: "",
      uf: "",
    },
    curriculo: null,
    documentoCPF: null,
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name in formData.endereco) {
      setFormData((prev) => ({
        ...prev,
        endereco: { ...prev.endereco, [name]: value },
      }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleCepSearch = async () => {
    const cep = formData.endereco.cep.replace(/\D/g, ""); // Remove caracteres não numéricos
    if (cep.length !== 8) {
      alert("CEP inválido. Por favor, digite 8 dígitos.");
      return;
    }

    try {
      const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
      const data = await response.json();

      if (data.erro) {
        alert("CEP não encontrado.");
        return;
      }

      setFormData((prev) => ({
        ...prev,
        endereco: {
          ...prev.endereco,
          logradouro: data.logradouro,
          bairro: data.bairro,
          cidade: data.localidade,
          uf: data.uf,
        },
      }));
    } catch (error) {
      console.error("Erro ao buscar CEP:", error);
      alert("Erro ao buscar CEP. Verifique sua conexão ou tente novamente.");
    }
  };

  const handleFileChange = (e) => {
    const { name, files } = e.target;
    setFormData((prev) => ({ ...prev, [name]: files[0] }));
  };

  const handleNext = () => {
    if (
      !formData.nomeCompleto ||
      !formData.email ||
      !formData.telefone ||
      !formData.endereco.cep ||
      !formData.endereco.logradouro ||
      !formData.endereco.numero ||
      !formData.endereco.bairro ||
      !formData.endereco.cidade ||
      !formData.endereco.uf ||
      !formData.curriculo ||
      !formData.documentoCPF
    ) {
      alert("Preencha todos os campos e envie os documentos obrigatórios.");
      return;
    }
    onNext({ tipo: "fisica", ...formData });
  };

  return (
    <div className="mt-6 p-4 border rounded shadow-lg">
      <h2 className="text-xl font-bold mb-4">Pessoa Física</h2>

      <div className="mb-4">
        <label className="block mb-2">Nome Completo *</label>
        <input
          type="text"
          name="nomeCompleto"
          value={formData.nomeCompleto}
          onChange={handleChange}
          className="border p-2 w-full"
        />
      </div>

      <div className="mb-4">
        <label className="block mb-2">Email *</label>
        <input
          type="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          className="border p-2 w-full"
        />
      </div>

      <div className="mb-4">
        <label className="block mb-2">Telefone *</label>
        <input
          type="text"
          name="telefone"
          value={formData.telefone}
          onChange={handleChange}
          className="border p-2 w-full"
        />
      </div>

      <h3 className="font-semibold mb-2">Endereço</h3>
      
      {/* Campo de CEP e botão de busca */}
      <div className="mb-2">
        <label className="block mb-1">CEP *</label>
        <div className="flex">
          <input
            type="text"
            name="cep"
            value={formData.endereco.cep}
            onChange={handleChange}
            maxLength="9"
            className="border p-2 w-full"
          />
          <button
            type="button"
            onClick={handleCepSearch}
            className="ml-2 bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
          >
            Buscar CEP
          </button>
        </div>
      </div>

      <div className="mb-2">
        <label className="block mb-1">Logradouro *</label>
        <input
          type="text"
          name="logradouro"
          value={formData.endereco.logradouro}
          onChange={handleChange}
          disabled={!!formData.endereco.logradouro}
          className="border p-2 w-full disabled:bg-gray-200"
        />
      </div>

      <div className="mb-2">
        <label className="block mb-1">Número *</label>
        <input
          type="text"
          name="numero"
          value={formData.endereco.numero}
          onChange={handleChange}
          className="border p-2 w-full"
        />
      </div>

      <div className="mb-2">
        <label className="block mb-1">Bairro *</label>
        <input
          type="text"
          name="bairro"
          value={formData.endereco.bairro}
          onChange={handleChange}
          disabled={!!formData.endereco.bairro}
          className="border p-2 w-full disabled:bg-gray-200"
        />
      </div>

      <div className="mb-2">
        <label className="block mb-1">Cidade *</label>
        <input
          type="text"
          name="cidade"
          value={formData.endereco.cidade}
          onChange={handleChange}
          disabled={!!formData.endereco.cidade}
          className="border p-2 w-full disabled:bg-gray-200"
        />
      </div>

      <div className="mb-2">
        <label className="block mb-1">UF *</label>
        <input
          type="text"
          name="uf"
          value={formData.endereco.uf}
          onChange={handleChange}
          disabled={!!formData.endereco.uf}
          className="border p-2 w-full disabled:bg-gray-200"
        />
      </div>
      
      <div className="mb-4">
        <label className="block mb-2">Currículo *</label>
        <input
          type="file"
          name="curriculo"
          accept=".pdf,.doc,.docx"
          onChange={handleFileChange}
        />
      </div>

      <div className="mb-4">
        <label className="block mb-2">Documento com CPF *</label>
        <input
          type="file"
          name="documentoCPF"
          accept=".pdf,.jpg,.png"
          onChange={handleFileChange}
        />
      </div>

      <div className="flex justify-between">
        <button
          className="bg-gray-400 text-white px-4 py-2 rounded hover:bg-gray-500"
          onClick={onBack}
        >
          Voltar
        </button>
        <button
          className="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700"
          onClick={handleNext}
        >
          Salvar e Continuar
        </button>
      </div>
    </div>
  );
}

export default PessoaFisicaForm;