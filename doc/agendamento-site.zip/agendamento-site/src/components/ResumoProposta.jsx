import React from 'react';

function ResumoProposta({ dadosProposta, onConfirm, onBack }) {
    // Componente de resumo da proposta
    return (
        <div className="mt-6 p-4 border rounded shadow-lg">
            <h2 className="text-2xl font-bold mb-4">Revisar Proposta</h2>
            
            <div className="p-4 bg-gray-50 border rounded mb-4">
                <h3 className="text-xl font-semibold mb-2">Dados da Proposta</h3>
                
                <p className="mb-1"><span className="font-medium">Nome do Evento:</span> {dadosProposta.nomeEvento}</p>
                
                <div className="mt-2">
                    <p className="font-medium">Área/Segmento:</p>
                    <ul className="list-disc list-inside">
                        {dadosProposta.areaSegmento.map((item, index) => <li key={index}>{item}</li>)}
                    </ul>
                </div>

                <div className="mt-2">
                    <p className="font-medium">Finalidade:</p>
                    <ul className="list-disc list-inside">
                        {dadosProposta.finalidade.map((item, index) => <li key={index}>{item}</li>)}
                    </ul>
                </div>
                
                <div className="mt-2">
                    <p className="font-medium">Sinopse:</p>
                    <p className="whitespace-pre-wrap">{dadosProposta.sinopse}</p>
                </div>
                
                <div className="mt-2">
                    <p className="font-medium">Demais especificações técnicas:</p>
                    <p className="whitespace-pre-wrap">{dadosProposta.especificacoesTecnicas || "N/A"}</p>
                </div>
                
                <div className="mt-2">
                    <p className="font-medium">Relevância cultural e impacto social:</p>
                    <p className="whitespace-pre-wrap">{dadosProposta.relevanciaSocial}</p>
                </div>

                {dadosProposta.linksProposta.length > 0 && (
                    <div className="mt-2">
                        <p className="font-medium">Links da Proposta:</p>
                        <ul className="list-disc list-inside">
                            {dadosProposta.linksProposta.map((link, index) => <li key={index}><a href={link} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">{link}</a></li>)}
                        </ul>
                    </div>
                )}

                {dadosProposta.linksOutros.length > 0 && (
                    <div className="mt-2">
                        <p className="font-medium">Outros Links:</p>
                        <ul className="list-disc list-inside">
                            {dadosProposta.linksOutros.map((link, index) => <li key={index}><a href={link} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">{link}</a></li>)}
                        </ul>
                    </div>
                )}
                
                {dadosProposta.arquivoProposta && (
                    <div className="mt-2">
                        <p className="font-medium">Arquivo da Proposta:</p>
                        <p>{dadosProposta.arquivoProposta.name}</p>
                    </div>
                )}

                {dadosProposta.outrosArquivos && (
                    <div className="mt-2">
                        <p className="font-medium">Arquivos Complementares:</p>
                        <p>{dadosProposta.outrosArquivos.name}</p>
                    </div>
                )}
                
                {dadosProposta.fichaTecnica && (
                    <div className="mt-2">
                        <p className="font-medium">Ficha Técnica:</p>
                        <p>{dadosProposta.fichaTecnica.name}</p>
                    </div>
                )}

            </div>

            <div className="flex justify-between mt-6">
                <button
                    className="bg-gray-400 text-white px-4 py-2 rounded hover:bg-gray-500"
                    onClick={onBack}
                >
                    Voltar
                </button>
                <button
                    onClick={onConfirm}
                    className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
                >
                    Confirmar e Continuar
                </button>
            </div>
        </div>
    );
}

export default ResumoProposta;