import React, { useRef, useState } from "react";

function ResumoTotal({ dadosCompletos, onBack }) {
  const contentRef = useRef(null);
  const [pdfLink, setPdfLink] = useState(null);
  const [loading, setLoading] = useState(false);

  // Função para enviar os dados ao backend
  const handleFinalizar = async () => {
    try {
      setLoading(true);

      const formData = new FormData();
      formData.append("dados", JSON.stringify(dadosCompletos));

      // Coleta todos os arquivos e os anexa ao FormData
      const arquivos = dadosCompletos.arquivos || {};
      for (const key in arquivos) {
        if (arquivos[key] instanceof File) {
          // A chave 'arquivos' é o nome do campo que o Multer espera no backend
          formData.append("arquivos", arquivos[key], arquivos[key].name);
        }
      }

      const response = await fetch("/api/inscricao", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        // Se a resposta não for 2xx, lança um erro com a mensagem do servidor
        const errorData = await response.json();
        throw new Error(errorData.message || "Erro desconhecido ao enviar dados.");
      }

      const result = await response.json();

      if (result.success) {
        setPdfLink(result.pdf);
        alert("Inscrição concluída com sucesso!");
      } else {
        alert("Erro ao concluir inscrição.");
      }
    } catch (error) {
      console.error("Erro ao enviar os dados:", error);
      alert(`Erro ao enviar os dados: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const {
    localSelecionado,
    resumoAgendamento,
    dadosPessoa,
    dadosProposta,
    dadosAcessibilidade,
    dadosGratuidade,
  } = dadosCompletos;

  const renderSection = (title, content) => (
    <div className="mb-4">
      <h3 className="text-xl font-semibold border-b-2 pb-1 mb-2">
        {title}
      </h3>
      <div className="text-sm space-y-1">
        {content}
      </div>
    </div>
  );

  return (
    <div className="p-6 border rounded shadow-lg">
      <h2 className="text-2xl font-bold mb-4">Resumo Final da Inscrição</h2>

      <div ref={contentRef} className="space-y-6">
        {renderSection(
          "Detalhes do Agendamento",
          <>
            <p><strong>Local Selecionado:</strong> {localSelecionado === 'teatro' ? 'Teatro' : 'Igrejinha'}</p>
            {resumoAgendamento?.evento?.length > 0 && (
              <>
                <p className="font-medium">Eventos Principais:</p>
                <ul className="list-disc list-inside ml-4">
                  {resumoAgendamento.evento.map((evento, index) => (
                    <li key={index}>
                      Data: {new Date(evento.date).toLocaleDateString()}, Horário: {evento.start} - {evento.end}
                    </li>
                  ))}
                </ul>
              </>
            )}
          </>
        )}

        {renderSection(
          "Dados Pessoais",
          dadosPessoa && (
            <>
              <p><strong>Tipo:</strong> {dadosPessoa.tipo === 'fisica' ? 'Pessoa Física' : 'Pessoa Jurídica'}</p>
              <p><strong>Nome Completo:</strong> {dadosPessoa.nomeCompleto}</p>
              <p><strong>Email:</strong> {dadosPessoa.email}</p>
              <p><strong>Telefone:</strong> {dadosPessoa.telefone}</p>
              {dadosPessoa.endereco && (
                <p><strong>Endereço:</strong> {dadosPessoa.endereco.logradouro}, {dadosPessoa.endereco.numero}, {dadosPessoa.endereco.bairro}, {dadosPessoa.endereco.cidade} - {dadosPessoa.endereco.uf}</p>
              )}
            </>
          )
        )}
        
        {renderSection(
          "Dados da Proposta",
          dadosProposta && (
            <>
              <p><strong>Nome do Evento:</strong> {dadosProposta.nomeEvento}</p>
              <p><strong>Área/Segmento:</strong> {dadosProposta.areaSegmento?.join(', ')}</p>
              <p><strong>Finalidade:</strong> {dadosProposta.finalidade?.join(', ')}</p>
              <p><strong>Sinopse:</strong> {dadosProposta.sinopse}</p>
              <p><strong>Relevância Social:</strong> {dadosProposta.relevanciaSocial}</p>
            </>
          )
        )}
        
        {renderSection(
          "Acessibilidade",
          dadosAcessibilidade && (
            <>
              <p><strong>Disponibiliza:</strong> {dadosAcessibilidade.disponibiliza}</p>
              {dadosAcessibilidade.recursos?.length > 0 && (
                <p><strong>Recursos:</strong> {dadosAcessibilidade.recursos.join(', ')}</p>
              )}
            </>
          )
        )}
        
        {renderSection(
          "Gratuidade",
          dadosGratuidade && (
            <>
              <p><strong>É gratuito?</strong> {dadosGratuidade.gratuito === 'sim' ? 'Sim' : 'Não'}</p>
              {dadosGratuidade.observacoes && (
                <p><strong>Observações:</strong> {dadosGratuidade.observacoes}</p>
              )}
            </>
          )
        )}
      </div>

      <div className="flex justify-between mt-6">
        <button
          className="bg-gray-400 text-white px-4 py-2 rounded hover:bg-gray-500"
          onClick={onBack}
        >
          Voltar
        </button>
        <button
          className="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700 disabled:opacity-50"
          onClick={handleFinalizar}
          disabled={loading}
        >
          {loading ? "Enviando..." : "Concluir"}
        </button>
      </div>

      {pdfLink && (
        <div className="mt-6 p-4 bg-green-100 border border-green-400 rounded">
          <p className="font-semibold text-green-800">
            Sua inscrição foi salva com sucesso!
          </p>
          <a
            href={`http://localhost:3000${pdfLink}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-blue-600 underline"
          >
            Baixar resumo em PDF
          </a>
        </div>
      )}
    </div>
  );
}

export default ResumoTotal;