import React, { useState, useRef, useEffect } from "react";

function DadosDaProposta({ onNext, onBack }) {
  const [nomeEvento, setNomeEvento] = useState("");
  const [areaSegmento, setAreaSegmento] = useState([]);
  const [finalidade, setFinalidade] = useState([]);
  const [sinopse, setSinopse] = useState("");
  const [relevanciaSocial, setRelevanciaSocial] = useState("");
  const [especificacoesTecnicas, setEspecificacoesTecnicas] = useState("");
  const [linksProposta, setLinksProposta] = useState([""]);
  const [linksOutros, setLinksOutros] = useState([""]);
  const [arquivoProposta, setArquivoProposta] = useState(null);
  const [outrosArquivos, setOutrosArquivos] = useState(null);
  const [fichaTecnica, setFichaTecnica] = useState(null);
  const [showError, setShowError] = useState(false);

  const sinopseRef = useRef(null);
  const relevanciaRef = useRef(null);
  const especificacoesRef = useRef(null);
  
  // Função para redimensionamento automático de textareas
  const autoResize = (ref) => {
    if (ref.current) {
      ref.current.style.height = "auto";
      ref.current.style.height = ref.current.scrollHeight + "px";
    }
  };

  useEffect(() => {
    autoResize(sinopseRef);
  }, [sinopse]);
  
  useEffect(() => {
    autoResize(relevanciaRef);
  }, [relevanciaSocial]);

  useEffect(() => {
    autoResize(especificacoesRef);
  }, [especificacoesTecnicas]);

  // Função para adicionar um novo campo de link
  const handleAddLink = (type) => {
    if (type === "proposta") {
      setLinksProposta([...linksProposta, ""]);
    } else if (type === "outros") {
      setLinksOutros([...linksOutros, ""]);
    }
  };
  
  // Função para remover um campo de link
  const handleRemoveLink = (type, index) => {
    if (type === "proposta") {
      const newLinks = [...linksProposta];
      newLinks.splice(index, 1);
      setLinksProposta(newLinks);
    } else if (type === "outros") {
      const newLinks = [...linksOutros];
      newLinks.splice(index, 1);
      setLinksOutros(newLinks);
    }
  };

  // Função para lidar com a mudança nos campos de link
  const handleLinkChange = (type, index, value) => {
    if (type === "proposta") {
      const newLinks = [...linksProposta];
      newLinks[index] = value;
      setLinksProposta(newLinks);
    } else if (type === "outros") {
      const newLinks = [...linksOutros];
      newLinks[index] = value;
      setLinksOutros(newLinks);
    }
  };

  // Funções para lidar com os uploads de arquivo
  const handleArquivoPropostaChange = (e) => {
    setArquivoProposta(e.target.files[0]);
  };

  const handleOutrosArquivosChange = (e) => {
    setOutrosArquivos(e.target.files[0]);
  };

  const handleFichaTecnicaChange = (e) => {
    setFichaTecnica(e.target.files[0]);
  };

  const handleSaveAndContinue = () => {
    if (!nomeEvento || areaSegmento.length === 0 || finalidade.length === 0 || !sinopse || !relevanciaSocial || !fichaTecnica) {
      setShowError(true);
      return;
    }
    
    // Filtra links vazios
    const linksPropostaFiltrados = linksProposta.filter(link => link.trim() !== "");
    const linksOutrosFiltrados = linksOutros.filter(link => link.trim() !== "");

    onNext({
      nomeEvento,
      areaSegmento,
      finalidade,
      sinopse,
      relevanciaSocial,
      especificacoesTecnicas,
      linksProposta: linksPropostaFiltrados,
      linksOutros: linksOutrosFiltrados,
      arquivoProposta,
      outrosArquivos,
      fichaTecnica,
    });
  };

  const isNextButtonEnabled = nomeEvento && areaSegmento.length > 0 && finalidade.length > 0 && sinopse && relevanciaSocial && fichaTecnica;

  return (
    <div className="p-6 bg-white rounded-xl shadow-lg w-full max-w-4xl mx-auto my-8 font-sans">
      <h2 className="text-2xl font-bold mb-6 text-purple-700">Dados da Proposta</h2>

      {showError && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
          <strong className="font-bold">Erro!</strong>
          <span className="block sm:inline ml-2">Por favor, preencha todos os campos obrigatórios.</span>
          <span className="absolute top-0 bottom-0 right-0 px-4 py-3">
            <svg onClick={() => setShowError(false)} className="fill-current h-6 w-6 text-red-500" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><title>Close</title><path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.03a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z"/></svg>
          </span>
        </div>
      )}

      <div className="mb-4">
        <label className="block mb-2 font-semibold">Nome do Evento/Proposta *</label>
        <input
          type="text"
          value={nomeEvento}
          onChange={(e) => setNomeEvento(e.target.value)}
          className="border border-gray-300 p-2 w-full rounded-lg"
          required
        />
      </div>

      <div className="mb-4">
        <label className="block mb-2 font-semibold">Área/Segmento *</label>
        {/* Lógica para selecionar áreas/segmentos */}
        <p className="text-gray-500 text-sm">Selecione uma ou mais áreas.</p>
        <div className="flex flex-wrap gap-2 mt-2">
          {["Música", "Dança", "Teatro", "Artes Visuais", "Audiovisual", "Artes Circenses", "Literatura", "Culturas Populares e Saberes Tradicionais", "Políticas Culturais e Gestão da Cultura"].map((area) => (
            <button
              key={area}
              type="button"
              onClick={() => {
                setAreaSegmento((prev) =>
                  prev.includes(area)
                    ? prev.filter((a) => a !== area)
                    : [...prev, area]
                );
              }}
              className={`px-4 py-2 rounded-full border transition-colors duration-200 ${
                areaSegmento.includes(area)
                  ? "bg-purple-600 text-white border-purple-600"
                  : "bg-gray-200 text-gray-700 hover:bg-gray-300"
              }`}
            >
              {area}
            </button>
          ))}
        </div>
      </div>
      
      <div className="mb-4">
        <label className="block mb-2 font-semibold">Finalidade da atividade artístico-cultural *</label>
        {/* Lógica para selecionar finalidades */}
        <p className="text-gray-500 text-sm">Selecione uma ou mais finalidades.</p>
        <div className="flex flex-wrap gap-2 mt-2">
          {["Formação", "Apresentação", "Oficina", "Ensaio", "Exposição", "Debate/Congresso"].map((finalidadeItem) => (
            <button
              key={finalidadeItem}
              type="button"
              onClick={() => {
                setFinalidade((prev) =>
                  prev.includes(finalidadeItem)
                    ? prev.filter((f) => f !== finalidadeItem)
                    : [...prev, finalidadeItem]
                );
              }}
              className={`px-4 py-2 rounded-full border transition-colors duration-200 ${
                finalidade.includes(finalidadeItem)
                  ? "bg-purple-600 text-white border-purple-600"
                  : "bg-gray-200 text-gray-700 hover:bg-gray-300"
              }`}
            >
              {finalidadeItem}
            </button>
          ))}
        </div>
      </div>

      <div className="mb-4">
        <label className="block mb-2 font-semibold">Sinopse da Proposta *</label>
        <textarea
          ref={sinopseRef}
          value={sinopse}
          onChange={(e) => setSinopse(e.target.value)}
          className="border border-gray-300 p-2 w-full rounded-lg resize-none overflow-hidden"
          rows="1"
          required
        />
      </div>

      <div className="mb-4">
        <label className="block mb-2 font-semibold">Breve descrição sobre a relevância cultural e impacto social da proposta *</label>
        <textarea
          ref={relevanciaRef}
          value={relevanciaSocial}
          onChange={(e) => setRelevanciaSocial(e.target.value)}
          className="border border-gray-300 p-2 w-full rounded-lg resize-none overflow-hidden"
          rows="1"
          required
        />
      </div>

      <div className="mb-4">
        <label className="block mb-2 font-semibold">Especificações Técnicas (Opcional)</label>
        <textarea
          ref={especificacoesRef}
          value={especificacoesTecnicas}
          onChange={(e) => setEspecificacoesTecnicas(e.target.value)}
          className="border border-gray-300 p-2 w-full rounded-lg resize-none overflow-hidden"
          rows="1"
        />
      </div>

      <div className="mb-4">
        <label className="block mb-2 font-semibold">Links da Proposta (Opcional)</label>
        {linksProposta.map((link, index) => (
          <div key={index} className="flex items-center gap-2 mb-2">
            <input
              type="text"
              placeholder="URL do link"
              value={link}
              onChange={(e) => handleLinkChange("proposta", index, e.target.value)}
              className="border border-gray-300 p-2 flex-grow rounded-lg"
            />
            {linksProposta.length > 1 && (
              <button
                type="button"
                onClick={() => handleRemoveLink("proposta", index)}
                className="bg-red-500 text-white p-2 rounded-full h-8 w-8 flex items-center justify-center hover:bg-red-600 transition duration-200"
              >
                -
              </button>
            )}
          </div>
        ))}
        <button
          type="button"
          onClick={() => handleAddLink("proposta")}
          className="bg-green-500 text-white px-4 py-2 rounded-full hover:bg-green-600 transition duration-200"
        >
          + Adicionar Link
        </button>
      </div>

      <div className="mb-4">
        <label className="block mb-2 font-semibold">Outros Links (Opcional)</label>
        {linksOutros.map((link, index) => (
          <div key={index} className="flex items-center gap-2 mb-2">
            <input
              type="text"
              placeholder="URL do link"
              value={link}
              onChange={(e) => handleLinkChange("outros", index, e.target.value)}
              className="border border-gray-300 p-2 flex-grow rounded-lg"
            />
            {linksOutros.length > 1 && (
              <button
                type="button"
                onClick={() => handleRemoveLink("outros", index)}
                className="bg-red-500 text-white p-2 rounded-full h-8 w-8 flex items-center justify-center hover:bg-red-600 transition duration-200"
              >
                -
              </button>
            )}
          </div>
        ))}
        <button
          type="button"
          onClick={() => handleAddLink("outros")}
          className="bg-green-500 text-white px-4 py-2 rounded-full hover:bg-green-600 transition duration-200"
        >
          + Adicionar Link
        </button>
      </div>

      <div className="mb-4">
        <label className="block mb-2 font-semibold">Arquivo da Proposta (Opcional)</label>
        <input
          type="file"
          accept=".pdf,image/*,video/*"
          onChange={handleArquivoPropostaChange}
          className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-purple-50 file:text-purple-700 hover:file:bg-purple-100"
        />
        {arquivoProposta && (
          <p className="mt-2 text-sm text-gray-600">Arquivo selecionado: {arquivoProposta.name}</p>
        )}
      </div>

      <div className="mb-4">
        <label className="block mb-2 font-semibold">Outros Arquivos (Opcional)</label>
        <input
          type="file"
          accept=".pdf,image/*,video/*"
          onChange={handleOutrosArquivosChange}
          className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-purple-50 file:text-purple-700 hover:file:bg-purple-100"
        />
        {outrosArquivos && (
          <p className="mt-2 text-sm text-gray-600">Arquivo selecionado: {outrosArquivos.name}</p>
        )}
      </div>
      
      <div className="mb-4">
        <label className="block mb-2 font-semibold">Ficha Técnica *</label>
        <input
          type="file"
          accept=".pdf,image/*,video/*"
          onChange={handleFichaTecnicaChange}
          className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-purple-50 file:text-purple-700 hover:file:bg-purple-100"
          required
        />
        {fichaTecnica && (
          <p className="mt-2 text-sm text-gray-600">Arquivo selecionado: {fichaTecnica.name}</p>
        )}
      </div>

      <div className="flex justify-between mt-6">
        <button
          className="bg-gray-400 text-white px-4 py-2 rounded-lg hover:bg-gray-500 transition duration-200"
          onClick={onBack}
        >
          Voltar
        </button>
        <button
          onClick={handleSaveAndContinue}
          disabled={!isNextButtonEnabled}
          className={`px-4 py-2 rounded-lg transition duration-200 ${
            isNextButtonEnabled
              ? "bg-purple-600 text-white hover:bg-purple-700"
              : "bg-gray-300 text-gray-500 cursor-not-allowed"
          }`}
        >
          Salvar e Continuar
        </button>
      </div>
    </div>
  );
}

export default DadosDaProposta;
