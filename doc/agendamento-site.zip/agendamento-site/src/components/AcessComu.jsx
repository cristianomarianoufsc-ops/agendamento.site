import React, { useState } from "react";

function AcessComu({ onNext, onBack }) {
    const [usaAcessibilidade, setUsaAcessibilidade] = useState(null);
    const [recursos, setRecursos] = useState({
        libras: false,
        audiodescricao: false,
        legendas: false,
        outro: ""
    });

    const handleAcessibilidadeChange = (resposta) => {
        setUsaAcessibilidade(resposta);
        // Reseta os recursos se a resposta for "Não"
        if (resposta === 'nao') {
            setRecursos({
                libras: false,
                audiodescricao: false,
                legendas: false,
                outro: ""
            });
        }
    };

    const handleRecursosChange = (e) => {
        const { name, checked, value } = e.target;
        if (e.target.type === "checkbox") {
            setRecursos(prev => ({
                ...prev,
                [name]: checked
            }));
        } else {
            setRecursos(prev => ({
                ...prev,
                [name]: value
            }));
        }
    };

    const handleSaveAndContinue = () => {
        let dadosAcessibilidade;
        if (usaAcessibilidade === 'sim') {
            const recursosSelecionados = Object.entries(recursos)
                .filter(([key, value]) => key !== 'outro' && value)
                .map(([key]) => {
                    switch (key) {
                        case 'libras': return 'Intérprete de libras';
                        case 'audiodescricao': return 'Audiodescrição';
                        case 'legendas': return 'Legendas';
                        default: return key;
                    }
                });

            if (recursos.outro.trim() !== "") {
                recursosSelecionados.push(`Outro: ${recursos.outro}`);
            }

            if (recursosSelecionados.length === 0) {
                alert("Por favor, selecione pelo menos um recurso de acessibilidade ou clique em 'Não'.");
                return;
            }
            dadosAcessibilidade = {
                disponibiliza: "Sim",
                recursos: recursosSelecionados
            };
        } else {
            dadosAcessibilidade = { disponibiliza: "Não" };
        }

        onNext(dadosAcessibilidade);
    };

    const isNextButtonEnabled = usaAcessibilidade === 'nao' || (usaAcessibilidade === 'sim' && (recursos.libras || recursos.audiodescricao || recursos.legendas || recursos.outro.trim() !== ""));

    return (
        <div className="mt-6 p-4 border rounded shadow-lg">
            <h2 className="text-xl font-bold mb-4">Acessibilidade Comunicacional</h2>
            
            <div className="mb-4">
                <p className="block mb-2 font-semibold">O evento disponibiliza recursos de acessibilidade comunicacional? *</p>
                <div className="flex gap-4 mt-2">
                    <button
                        onClick={() => handleAcessibilidadeChange('sim')}
                        className={`px-4 py-2 rounded ${usaAcessibilidade === 'sim' ? 'bg-blue-600 text-white font-bold' : 'bg-gray-200'}`}
                    >
                        Sim
                    </button>
                    <button
                        onClick={() => handleAcessibilidadeChange('nao')}
                        className={`px-4 py-2 rounded ${usaAcessibilidade === 'nao' ? 'bg-blue-600 text-white font-bold' : 'bg-gray-200'}`}
                    >
                        Não
                    </button>
                </div>
            </div>

            {usaAcessibilidade === 'sim' && (
                <div className="p-4 bg-gray-100 border rounded mt-4">
                    <p className="block mb-2 font-semibold">Quais recursos de acessibilidade comunicacional serão utilizados? *</p>
                    <div className="flex flex-col gap-2 mt-2">
                        <label className="flex items-center">
                            <input
                                type="checkbox"
                                name="libras"
                                checked={recursos.libras}
                                onChange={handleRecursosChange}
                                className="mr-2"
                            />
                            Intérprete de libras
                        </label>
                        <label className="flex items-center">
                            <input
                                type="checkbox"
                                name="audiodescricao"
                                checked={recursos.audiodescricao}
                                onChange={handleRecursosChange}
                                className="mr-2"
                            />
                            Audiodescrição
                        </label>
                        <label className="flex items-center">
                            <input
                                type="checkbox"
                                name="legendas"
                                checked={recursos.legendas}
                                onChange={handleRecursosChange}
                                className="mr-2"
                            />
                            Legendas
                        </label>
                        <label className="flex items-center">
                            <span className="mr-2">Outro:</span>
                            <input
                                type="text"
                                name="outro"
                                value={recursos.outro}
                                onChange={handleRecursosChange}
                                className="border p-1 rounded flex-grow"
                            />
                        </label>
                    </div>
                </div>
            )}

            <div className="flex justify-between mt-6">
                <button
                    className="bg-gray-400 text-white px-4 py-2 rounded hover:bg-gray-500"
                    onClick={onBack}
                >
                    Voltar
                </button>
                <button
                    onClick={handleSaveAndContinue}
                    disabled={!isNextButtonEnabled}
                    className={`px-4 py-2 rounded ${isNextButtonEnabled ? "bg-purple-600 text-white hover:bg-purple-700" : "bg-gray-300 text-gray-500 cursor-not-allowed"}`}
                >
                    Salvar e Continuar
                </button>
            </div>
        </div>
    );
}

export default AcessComu;