// src/components/PessoaJuridicaForm.jsx
import React, { useState } from "react";

function PessoaJuridicaForm({ onNext, onBack }) {
  const [representante, setRepresentante] = useState("");
  const [email, setEmail] = useState("");
  const [telefone, setTelefone] = useState("");
  const [cnpj, setCnpj] = useState("");
  const [razaoSocial, setRazaoSocial] = useState("");
  const [endereco, setEndereco] = useState({
    cep: "",
    logradouro: "",
    bairro: "",
    cidade: "",
    estado: "",
    numero: "",
    complemento: "",
  });
  const [docCpfFile, setDocCpfFile] = useState(null);
  const [portfolioFile, setPortfolioFile] = useState(null);
  const [contratoSocialFile, setContratoSocialFile] = useState(null);
  const [cnpjFile, setCnpjFile] = useState(null);
  
  const buscarCnpj = async () => {
    const cleanCnpj = cnpj.replace(/\D/g, "");
    if (cleanCnpj.length !== 14) return;
    try {
      const res = await fetch(`/api_cnpj/cnpj/${cleanCnpj}`);
      const data = await res.json();
      if (data && !data.error) {
        setRazaoSocial(data.nome);
        setEndereco((prev) => ({
          ...prev,
          cep: data.cep.replace(/\D/g, ""),
          logradouro: data.logradouro,
          bairro: data.bairro,
          cidade: data.municipio,
          estado: data.uf,
        }));
      }
    } catch (error) {
      console.error("Erro ao buscar CNPJ:", error);
    }
  };

  const buscarCep = async () => {
    const cleanCep = endereco.cep.replace(/\D/g, "");
    if (cleanCep.length !== 8) return;
    try {
      const res = await fetch(`https://viacep.com.br/ws/${cleanCep}/json/`);
      const data = await res.json();
      if (!data.erro) {
        setEndereco((prev) => ({
          ...prev,
          logradouro: data.logradouro,
          bairro: data.bairro,
          cidade: data.localidade,
          estado: data.uf,
        }));
      }
    } catch (error) {
      console.error("Erro ao buscar CEP:", error);
    }
  };

  const handleNext = () => {
    if (!representante || !email || !telefone || !razaoSocial || !cnpj) {
      alert("Por favor, preencha todos os campos obrigatórios.");
      return;
    }
    
    const dadosPessoaJuridica = {
      tipo: 'juridica',
      representante,
      email,
      telefone,
      cnpj,
      razaoSocial,
      endereco,
      docCpfFile: docCpfFile ? docCpfFile.name : null,
      portfolioFile: portfolioFile ? portfolioFile.name : null,
      contratoSocialFile: contratoSocialFile ? contratoSocialFile.name : null,
      cnpjFile: cnpjFile ? cnpjFile.name : null,
    };
    
    onNext(dadosPessoaJuridica);
  };

  return (
    <div className="mt-6 p-4 border rounded shadow-lg">
      <h2 className="text-xl font-bold mb-4">Dados do Proponente - Pessoa Jurídica</h2>
      <div className="mb-4">
        <label className="block font-medium mb-1">Nome do Representante *</label>
        <input 
          type="text" 
          value={representante} 
          onChange={e => setRepresentante(e.target.value)} 
          className="border p-2 w-full mb-2" 
        />
        <label className="block font-medium mb-1">E-mail *</label>
        <input 
          type="email" 
          value={email} 
          onChange={e => setEmail(e.target.value)} 
          className="border p-2 w-full mb-2" 
        />
        <label className="block font-medium mb-1">Telefone *</label>
        <input 
          type="tel" 
          value={telefone} 
          onChange={e => setTelefone(e.target.value)} 
          className="border p-2 w-full mb-2" 
        />
        <label className="block font-medium mb-1">CNPJ *</label>
        <div className="flex mb-2">
          <input 
            type="text" 
            value={cnpj} 
            onChange={e => setCnpj(e.target.value)} 
            onBlur={buscarCnpj}
            className="border p-2 w-full mr-2" 
            placeholder="XX.XXX.XXX/XXXX-XX"
          />
          <button 
            onClick={buscarCnpj} 
            className="bg-blue-500 text-white p-2 rounded"
          >
            Buscar CNPJ
          </button>
        </div>
        <label className="block font-medium mb-1">Razão Social *</label>
        <input 
          type="text" 
          value={razaoSocial} 
          onChange={e => setRazaoSocial(e.target.value)} 
          className="border p-2 w-full mb-2" 
        />
        
        {/* Endereço */}
        <label className="block font-medium mb-1">CEP *</label>
        <div className="flex mb-2">
            <input 
                type="text" 
                value={endereco.cep} 
                onChange={e => setEndereco({ ...endereco, cep: e.target.value })} 
                onBlur={buscarCep}
                className="border p-2 w-2/3 mr-2" 
                placeholder="CEP"
            />
            <button 
                onClick={buscarCep} 
                className="bg-blue-500 text-white p-2 rounded w-1/3"
            >
                Buscar CEP
            </button>
        </div>
        <input 
            type="text" 
            value={endereco.logradouro} 
            onChange={e => setEndereco({ ...endereco, logradouro: e.target.value })} 
            className="border p-2 w-full mb-2" 
            placeholder="Logradouro" 
            disabled 
        />
        <input 
            type="text" 
            value={endereco.bairro} 
            onChange={e => setEndereco({ ...endereco, bairro: e.target.value })} 
            className="border p-2 w-full mb-2" 
            placeholder="Bairro" 
            disabled 
        />
        <input 
            type="text" 
            value={endereco.cidade} 
            onChange={e => setEndereco({ ...endereco, cidade: e.target.value })} 
            className="border p-2 w-full mb-2" 
            placeholder="Cidade" 
            disabled 
        />
        <input 
            type="text" 
            value={endereco.estado} 
            onChange={e => setEndereco({ ...endereco, estado: e.target.value })} 
            className="border p-2 w-full mb-2" 
            placeholder="Estado" 
            disabled 
        />
        <input 
            type="text" 
            value={endereco.numero} 
            onChange={e => setEndereco({ ...endereco, numero: e.target.value })} 
            className="border p-2 w-full mb-2" 
            placeholder="Número *" 
        />
        <input 
            type="text" 
            value={endereco.complemento} 
            onChange={e => setEndereco({ ...endereco, complemento: e.target.value })} 
            className="border p-2 w-full mb-4" 
            placeholder="Complemento" 
        />

        {/* Upload de arquivos */}
        <div className="mb-4">
            <label className="block font-medium mb-1">Documento oficial com foto e CPF do representante *</label>
            <input type="file" accept="application/pdf,image/*" onChange={e => setDocCpfFile(e.target.files[0])} className="mb-2" />
            <label className="block font-medium mb-1">Portfólio</label>
            <input type="file" accept="application/pdf,image/*" onChange={e => setPortfolioFile(e.target.files[0])} className="mb-2" />
            <label className="block font-medium mb-1">Cópia do Contrato Social e sua última alteração *</label>
            <input type="file" accept="application/pdf,image/*" onChange={e => setContratoSocialFile(e.target.files[0])} className="mb-2" />
            <label className="block font-medium mb-1">Cópia do documento Nacional de Pessoas Jurídicas - CNPJ *</label>
            <input type="file" accept="application/pdf,image/*" onChange={e => setCnpjFile(e.target.files[0])} className="mb-2" />
        </div>
      </div>
      
      <div className="flex justify-between mt-4">
        <button 
          className="bg-gray-400 text-white px-4 py-2 rounded hover:bg-gray-500"
          onClick={onBack}
        >
          Voltar
        </button>
        <button 
          onClick={handleNext} 
          className="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700"
        >
          Salvar e Continuar
        </button>
      </div>
    </div>
  );
}

export default PessoaJuridicaForm;