import React from 'react';

function CalendarGrid() {
  return (
    <div className="bg-white rounded-xl shadow p-4 mb-6">
      {/* Aqui futuramente você terá o calendário iCal/FullCalendar */}
      <p className="text-center text-gray-500">[Calendário em desenvolvimento]</p>
    </div>
  );
}

export default CalendarGrid;