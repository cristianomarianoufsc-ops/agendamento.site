// src/components/Proposta.jsx
import React, { useState } from "react";

function Proposta({ onNext, onBack }) {
  const [vinculo, setVinculo] = useState(null);
  const [descricaoVinculo, setDescricaoVinculo] = useState("");
  const [arquivoComprovante, setArquivoComprovante] = useState(null);

  const handleFileChange = (e) => {
    if (e.target.files.length > 0) {
      setArquivoComprovante(e.target.files[0]);
    }
  };

  const handleSaveAndContinue = () => {
    if (vinculo === null) {
      alert("Por favor, selecione se a proposta possui vínculo com a UFSC.");
      return;
    }
    if (vinculo === true && (!descricaoVinculo.trim() || !arquivoComprovante)) {
      alert("Por favor, descreva o vínculo institucional e anexe o comprovante.");
      return;
    }

    const dadosProposta = {
      vinculo,
      descricaoVinculo,
      arquivoComprovante: arquivoComprovante?.name || null,
    };
    
    onNext(dadosProposta);
  };
  
  const isNextButtonEnabled = vinculo === false || (vinculo === true && descricaoVinculo.trim() !== "" && arquivoComprovante);

  return (
    <div className="mt-6 p-4 border rounded shadow-lg">
      <h2 className="text-xl font-bold mb-4">Proposta</h2>
      
      <p className="text-sm text-gray-700 mb-4">
        Para os fins deste edital, de acordo com a Resolução Normativa nº 32/2024/CC, o vínculo da proposta com a UFSC será considerado:
        <br/><br/>
        I - promoção do evento, quando a sua organização estiver vinculada a órgão integrante da Administração Superior ou das unidades universitárias; e
        <br/>
        II – copromoção do evento, quando a sua organização estiver desvinculada dos órgãos a que se refere o inciso I, limitando-se a participação da Universidade a algum tipo de apoio institucional previamente definido.
        <br/><br/>
        Nos casos em que a atividade não se enquadrar numa das situações previstas nos itens acima, esta será considerada como externa.
      </p>

      <div className="mb-4">
        <label className="block mb-2 font-semibold">
          A proposta possui vínculo institucional com a UFSC?
        </label>
        <div className="flex space-x-4">
          <button
            onClick={() => setVinculo(true)}
            className={`px-4 py-2 rounded ${
              vinculo === true ? "bg-blue-600 text-white" : "bg-gray-200"
            }`}
          >
            Sim
          </button>
          <button
            onClick={() => setVinculo(false)}
            className={`px-4 py-2 rounded ${
              vinculo === false ? "bg-red-600 text-white" : "bg-gray-200"
            }`}
          >
            Não
          </button>
        </div>
      </div>

      {vinculo === true && (
        <div className="mt-4 p-4 border rounded bg-gray-50">
          <h4 className="font-semibold mb-2">Vínculo Institucional</h4>
          <p className="mb-2">Descreva brevemente o vínculo que possui com a Universidade e setor da UFSC:</p>
          <textarea
            className="border p-2 w-full h-24"
            placeholder="Descreva aqui..."
            value={descricaoVinculo}
            onChange={(e) => setDescricaoVinculo(e.target.value)}
          />
          <div className="mt-4">
            <label className="block font-medium mb-1">Comprovação da vinculação do projeto *</label>
            <input
              type="file"
              accept="application/pdf,image/*"
              onChange={handleFileChange}
            />
          </div>
        </div>
      )}

      <div className="flex justify-between mt-4">
        <button
          className="bg-gray-400 text-white px-4 py-2 rounded hover:bg-gray-500"
          onClick={onBack}
        >
          Voltar
        </button>
        <button
          onClick={handleSaveAndContinue}
          disabled={!isNextButtonEnabled}
          className={`px-4 py-2 rounded ${isNextButtonEnabled ? "bg-purple-600 text-white hover:bg-purple-700" : "bg-gray-300 text-gray-500 cursor-not-allowed"}`}
        >
          Salvar e Continuar
        </button>
      </div>
    </div>
  );
}

export default Proposta;