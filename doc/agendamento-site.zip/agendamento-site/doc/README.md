# 🎭 Sistema de Agendamento -- Teatro & Igrejinha (UFSC)

## 📌 Descrição

Este projeto é um sistema de agendamento online para os espaços
culturais da UFSC (Teatro Carmen Fossari e Igrejinha).\
Ele permite que usuários agendem diferentes **etapas** de um evento no
Google Calendar:

-   **Ensaio**
-   **Montagem**
-   **Evento** (pode ter múltiplos)
-   **Desmontagem**

O sistema garante que cada etapa seja registrada diretamente em uma
agenda do Google Calendar vinculada ao espaço cultural.

------------------------------------------------------------------------

## ⚙️ Tecnologias

-   **Frontend**: React + Tailwind
-   **Backend**: Node.js + Express
-   **Google Calendar API** via Service Account
-   **EmailJS** para envio de notificações
-   **PDFKit + html2pdf** para gerar resumos em PDF

------------------------------------------------------------------------

## 🔑 Funcionalidades

✅ Seleção de local (**Teatro** ou **Igrejinha**)\
✅ Escolha de datas e horários em blocos de 30min\
✅ Registro automático no **Google Calendar**\
✅ Suporte a várias etapas (ensaio, montagem, evento, desmontagem)\
✅ Cancelamento individual de etapas com sincronização no Calendar\
✅ Geração de **PDF** e opção de **imprimir** resumo\
✅ Botão **"Deletar Tudo"** foi **removido** (não é mais necessário)\
✅ Correção no mapeamento da etapa **montagem**, garantindo que IDs
corretos sejam salvos e deletados

------------------------------------------------------------------------

## 🗂️ Estrutura de Pastas

    /frontend
      ├── src
      │   ├── App.jsx       # Lógica principal do agendamento
      │   ├── components/
      │   │   ├── Calendar.jsx
      │   │   ├── TimeBlockSelector.jsx
      │   │   └── ...
    /backend
      ├── server.js         # API Express + integração Google Calendar
      ├── agendamento-teste-*.json  # Credenciais da Service Account

------------------------------------------------------------------------

## 🚀 Fluxo de Uso

1.  Usuário seleciona o **local** (Teatro ou Igrejinha).\
2.  Preenche dados básicos (**nome, email, telefone, nome do evento**).\
3.  Escolhe as **etapas** (ensaio, montagem, evento, desmontagem) e
    horários.\
4.  Ao confirmar, o backend cria os eventos no **Google Calendar**.\
5.  O usuário pode:
    -   **Remover etapas específicas** (com atualização no Calendar)\
    -   **Gerar PDF** do resumo\
    -   **Imprimir** o resumo\
    -   Avançar para a **segunda etapa**

------------------------------------------------------------------------

## 🔄 Alterações Recentes

-   Correção no **mapeamento da montagem** → agora IDs são
    salvos/deletados corretamente.\
-   Ajuste no **frontend** para vincular corretamente o `eventId` de
    cada etapa.\
-   **Botão "Deletar Tudo" removido** do fluxo, ficando apenas remoção
    individual de etapas.\
-   Backend atualizado para lidar melhor com erros de exclusão (eventos
    já inexistentes no Google Calendar).

------------------------------------------------------------------------

## 📌 Próximos Passos

-   Implementar a **segunda etapa** do agendamento.\
-   Melhorar **UI/UX** (alertas, feedback visual).\
-   Adicionar autenticação de usuários (opcional).
